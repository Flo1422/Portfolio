# FLO° – Konzept

## 1 · Analyse (Kurzfassung)

**Auftrag:** Portfolio zum Thema „Ich selbst“ im Rahmen der Erzieherausbildung. Materialien individuell und nachvollziehbar aufbereitet, persönliche Lernziele klar erkennbar. Reflexion erfolgt mündlich → keine Reflexions- oder Making-of-Seite.

**Leitmotiv:** ALLES HÄNGT ZUSAMMEN. Der Brief ist im Kern eine Geschichte von Verbindungen: Kita-Felix wird Dozent, Gaming führt zu Lasse und damit zum Freundeskreis, Graffiti führt zu Musik und Videoschnitt, Anthony verbindet Theater, FSJ, Graffiti und die heutige Kita. Dieses Motiv ist nicht nur Text, sondern das Gestaltungsprinzip der ganzen Seite.

**Heikle Stellen (bewusst sachlich):**
- 2021 / illegales Graffiti: nüchtern, eigene Tonalität, weder Drama noch Street-Romantik.
- Videoschnitt: Fähigkeit, keine Kindheitstraum-Story.
- Synchronsprechen: keine Projektnamen, keine Hörproben.
- Familie: nur, wer dazugehört (kein erzwungener Stammbaum), Ziehfamilie gleichwertig.
- Gleichnamige Personen: nie automatisch zusammenführen.
- Alter: nicht hart codiert – nur „November 2004“.

**Geklärte Identitäten (Stand jetzt):**
- Felix (Kita → Grundschule → Gymnasium → Theater → FSJ → Dozent) = eine Person → `p-felix-kita`
- Felix vom Gymnasium seit 2021, in den Freundeskreis geholt → `p-felix-gym`
- Felix, Cousin → `p-felix-cousin` · Felix Lobrecht → `p-felix-lobrecht`
- Jerome aus dem Hauptfreundeskreis, hat Jamie dazugeholt → `p-jerome-freunde`
- Jerome aus dem weiteren Motorradkreis, Stuntfahrer für Luvre47 → `p-jerome-moto`

**Noch offen (als `unconfirmed` markiert, keine Verbindung wird behauptet):**
Emil / Paul / Jason (Berufsschule ↔ Motorradkreise), Peer (Freundeskreis ↔ weiterer Motorradkreis), Basti (enger ↔ weiterer Motorradkreis), Erik (Verkäufer der SX-F 250 ↔ Motorradkreis), Anthony (Verkäufer der 690 SMC R = derselbe Anthony?), welcher Jerome von Anthony integriert wurde.

## 2 · Architektur

- **Next.js (App Router) + TypeScript**, statischer Export (`output: "export"`) → läuft überall (Vercel, Netlify, GitHub Pages, jeder Webspace).
- **GSAP + ScrollTrigger** für Scroll-Choreografie (Pinning, Scrub, Timelines).
- **Lenis** für Smooth Scrolling (bei reduced motion aus).
- **d3-force** nur zur Berechnung des Netzwerk-Layouts; gezeichnet wird in SVG (zugänglich, scharf, stylebar).
- **Kein Three.js** – kein echter gestalterischer Mehrwert gegenüber SVG/CSS-Tiefe.
- **CSS Modules + globale Design-Tokens** statt Utility-Framework → eigener, nicht-generischer Look.

```
src/
  app/            layout.tsx · page.tsx · globals.css
  data/           site · timeline · people · family · interests · bikes · graffiti · video · sport · development · goals · media
  lib/            gsap.ts · useReducedMotion · useIsTouch
  components/
    core/         SmoothScroll · Cursor · Grain · Header · Menu · Thread · Img(Slot) · Reveal · Magnetic
    sections/     Hero · Words · Teaser · About · Journey · Network · Family · Interests/* · Development · Goals · Outro
```

Alle Inhalte liegen in `src/data`. Komponenten lesen nur Daten. Fotos werden über `src/data/media.ts` Slots zugeordnet (`slot: "hero-1"` → Datei). Solange kein Foto hinterlegt ist, erscheint ein klar beschrifteter Platzhalter.

## 3 · Struktur & Verbindung der Bereiche

Eine durchgehende Scroll-Erzählung (One-Pager) mit sechs Kapiteln. Das Fullscreen-Menü springt mit Vorhang-Übergang in die Kapitel.

| # | Kapitel | Eigene Bewegungssprache |
|---|---|---|
| 0 | Intro / Hero | Collage in Tiefenebenen, Cursor-Parallax, Wortfolge, Jahres-Fragmente |
| 01 | Über mich | Magnetische Karten, Fotos kippen zur Maus, Interessenbegriffe driften im Hintergrund |
| 02 | Mein Weg | Linie zeichnet sich beim Scrollen, Jahreszahlen „rollen“, 2021 als ruhiger Bruch |
| 03 | Mein Umfeld | Netzwerk (Fokus/Dimmen), Familienbaum, „Kreis schließt sich“, Anthony-Kette |
| 04 | Meine Interessen | Garage (Auswahl), Wand (horizontal gepinnt), Video (Spuren/Playhead), Sport (Zeitbalken), Gaming, Musik |
| 05 | Meine Entwicklung | Pfad wächst und verzweigt sich (Elementar · Hort · Jugendarbeit), Integration quer |
| 06 | Meine Lernziele | Bewusst ruhig, drei Ziele nacheinander |
| — | Abschluss | „Was kommt danach?“ |

**Der rote Faden (visuell):** Links läuft ein feiner „Faden“ mit sechs Knoten durch die ganze Seite (Fortschritt + Kapitel). Dieselbe Formensprache – Punkt, Linie, Knoten – taucht im Hero, in der Timeline, im Netzwerk und im Entwicklungspfad wieder auf. Querverweise („→ siehe Mein Umfeld“) verknüpfen Kapitel inhaltlich.

## 4 · Designsystem

**Farben** – dunkle Ebenen statt reinem Schwarz:
`--bg-0 #0A0A0B` · `--bg-1 #111113` · `--bg-2 #18181B` · `--bg-3 #222226`
Text `--fg #EEEBE4` · `--fg-2 #A8A59F` · `--fg-3 #6E6C68` (nur groß/dekorativ)
Akzent (sparsam, „Sprühlack“) `--signal #E4572E`
Lebensbereiche (gedeckt, nur im Netzwerk/Timeline-Chips): Familie Sand · Kindheit Salbei · Freunde Kreide · Graffiti Signal · Musik Flieder · Motorrad Ocker · Ausbildung Stahlblau · Arbeit Türkisgrau.

**Typografie**
- Display: *Archivo* (variable, Breite + Gewicht) – groß, versal, eng.
- Editorial-Akzent: *Instrument Serif* kursiv – für persönliche Sätze.
- Meta: *JetBrains Mono* – Jahreszahlen, Labels, UI.
- Fluide Skala via `clamp()`: Mega 14–22vw · H1 12vw/9rem · H2 · H3 · Body 1.05–1.2rem · Meta 0.72rem.

**Spacing:** 4-px-Basis, Section-Abstand `clamp(6rem, 14vw, 14rem)`, Seitenrand `clamp(1rem, 4vw, 4rem)`.
**Grid:** 12 Spalten Desktop · 8 Tablet · 4 Mobile.
**Breakpoints:** 480 · 768 · 1024 · 1440.

**Animationsprinzipien**
1. Bewegung erklärt Zusammenhang – nie Selbstzweck.
2. Jedes Kapitel hat ein eigenes Muster (siehe Tabelle); kein generisches Fade-in.
3. Easing: `expo.out` für Reveals, `power2.inOut` für Übergänge, `none` bei Scrub.
4. Text wird maskiert enthüllt (Zeilen gleiten aus einer Maske).
5. Hover ist nie die einzige Informationsquelle – Touch & Tastatur bekommen gleichwertige Wege.
6. `prefers-reduced-motion`: Lenis aus, Pinning aus, alles sofort sichtbar – Inhalte bleiben vollständig.
