// Nur für die Einzeldatei-Vorschau (nicht für das eigentliche Deployment).
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { viteSingleFile } from "vite-plugin-singlefile";
import path from "node:path";
export default defineConfig({
  root: path.resolve(__dirname),
  plugins: [react(), viteSingleFile()],
  resolve: { alias: { "@": path.resolve(__dirname, "../src") } },
  build: { outDir: path.resolve(__dirname, "../preview-dist"), emptyOutDir: true, assetsInlineLimit: 100000000 },
});
