// Bettet die Fotos aus /public/media als data:-URLs in die Einzeldatei-Vorschau ein.
import fs from "node:fs";
import path from "node:path";
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const file = path.join(root, "preview-dist/index.html");
let html = fs.readFileSync(file, "utf8");
html = html.replace(/\/media\/([\w.-]+\.(jpe?g|png|webp))/g, (m, name, ext) => {
  const p = path.join(root, "public/media", name);
  if (!fs.existsSync(p)) return m;
  const mime = ext === "png" ? "image/png" : ext === "webp" ? "image/webp" : "image/jpeg";
  return `data:${mime};base64,${fs.readFileSync(p).toString("base64")}`;
});
fs.writeFileSync(file, html);
console.log("Vorschau:", Math.round(html.length / 1024), "KB");
