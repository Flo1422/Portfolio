import { createRoot } from "react-dom/client";
import "@fontsource-variable/archivo/wdth.css";
import "@fontsource/instrument-serif/latin-400.css";
import "@fontsource/instrument-serif/latin-400-italic.css";
import "@fontsource-variable/jetbrains-mono/wght.css";
import "../src/app/globals.css";
import "../src/app/core.css";
import Page from "../src/app/page";
createRoot(document.getElementById("root")!).render(<Page />);
