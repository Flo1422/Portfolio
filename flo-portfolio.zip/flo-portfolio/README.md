# FLO° – Persönliches Portfolio

Next.js · TypeScript · GSAP/ScrollTrigger · Lenis · d3-force (nur Layout-Berechnung) · statischer Export.

## Starten

```bash
npm install
npm run dev        # http://localhost:3000
npm run build      # erzeugt den statischen Ordner /out
```

`/out` kann auf jeden Webspace hochgeladen werden (Vercel, Netlify, GitHub Pages, …).

## Wo was liegt

| Was | Datei |
|---|---|
| Kapitel, Hero, Über mich, Abschluss | `src/data/site.ts` |
| Timeline „Mein Weg“ | `src/data/timeline.ts` |
| Personen, Bereiche, Verbindungen, Geschichten | `src/data/people.ts` |
| Familienbaum | `src/data/family.ts` |
| Motorräder, Graffiti, Video, Stimme, Sport, Gaming | `src/data/interests.ts` |
| Entwicklung | `src/data/development.ts` |
| Lernziele | `src/data/goals.ts` |
| **Bild-Slots** | `src/data/media.ts` (+ Garage/Wand direkt in `interests.ts`) |

Komponenten lesen nur aus diesen Dateien – Texte und Fotos werden dort geändert, nicht im Layout.

## Fotos einbauen

1. Datei nach `public/media/` legen (max. ca. 1600 px Breite, JPG/WebP).
2. Im passenden Slot `src: "/media/datei.jpg"` und eine sinnvolle `alt`-Beschreibung eintragen.
3. Optional `focus: "50% 30%"` für den Bildausschnitt.

Ohne Datei zeigt jeder Slot einen beschrifteten Platzhalter („Foto folgt“).

## Personen

Jede Person hat eine eindeutige ID (`p-felix-kita`, `p-felix-gym`, …). Gleichnamige Personen werden **nie automatisch** zusammengeführt. `unconfirmed: true` markiert Einträge, bei denen es eine gleichnamige Person in einem anderen Bereich gibt – bestätigt = beide Einträge zu einem zusammenführen (Bereiche vereinen).

## Barrierefreiheit & Bewegung

- `prefers-reduced-motion`: kein Smooth Scrolling, kein Pinning, alle Inhalte sofort sichtbar.
- Netzwerk: per Tastatur bedienbar, zusätzlich als Liste umschaltbar.
- Custom Cursor nur bei Maus, auf Touch-Geräten aus.

Einzeldatei-Vorschau (eine HTML-Datei, z. B. zum Verschicken): `npm run vorschau` → `preview-dist/index.html`.

Konzept & Designsystem: siehe `KONZEPT.md`.
