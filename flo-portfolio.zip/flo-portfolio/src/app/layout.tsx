import type { Metadata, Viewport } from "next";
// Selbst gehostete Schriften (keine Abhängigkeit zu Google beim Build/Laden)
import "@fontsource-variable/archivo/wdth.css";
import "@fontsource/instrument-serif/latin-400.css";
import "@fontsource/instrument-serif/latin-400-italic.css";
import "@fontsource-variable/jetbrains-mono/wght.css";
import "./globals.css";
import "./core.css";


export const metadata: Metadata = {
  title: "FLO° · Ein persönliches Portfolio",
  description: "Flo · Berlin · 2026. Mein Weg, mein Umfeld, meine Interessen, meine Entwicklung und meine Lernziele.",
};

export const viewport: Viewport = { themeColor: "#0a0a0b", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="de">
      <head>
        {/* Markiert, dass JS + Bewegung aktiv sind → erst dann werden Intro-Zustände versteckt */}
        <script
          dangerouslySetInnerHTML={{
            __html:
              "if(!window.matchMedia('(prefers-reduced-motion: reduce)').matches){document.documentElement.classList.add('js-motion')}",
          }}
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
