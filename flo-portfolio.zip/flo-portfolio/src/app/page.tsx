import { SmoothScroll } from "@/components/core/SmoothScroll";
import { Header } from "@/components/core/Header";
import { Thread } from "@/components/core/Thread";
import { Cursor } from "@/components/core/Cursor";
import { Grain } from "@/components/core/Grain";
import { Hero } from "@/components/sections/Hero";
import { Words } from "@/components/sections/Words";
import { Fragments } from "@/components/sections/Fragments";
import { About } from "@/components/sections/About";
import { Journey } from "@/components/sections/Journey";
import { Umfeld } from "@/components/sections/Umfeld";
import { Interests } from "@/components/interests/Interests";
import { Development } from "@/components/sections/Development";
import { Goals } from "@/components/sections/Goals";
import { Outro } from "@/components/sections/Outro";

export default function Page() {
  return (
    <SmoothScroll>
      <a className="skip" href="#ueber-mich">
        Zum Inhalt springen
      </a>
      <Header />
      <Thread />
      <main id="top">
        <Hero />
        <Words />
        <Fragments />
        <About />
        <Journey />
        <Umfeld />
        <Interests />
        <Development />
        <Goals />
      </main>
      <Outro />
      <Cursor />
      <Grain />
    </SmoothScroll>
  );
}
