import type { MediaId } from "./media";
import type { AreaId } from "./people";

export type TimelineEntry = {
  id: string;
  /** Anzeige, z. B. "2010–2016" oder "seit 2014" */
  when: string;
  /** Für Sortierung / Positionierung */
  year: number;
  title: string;
  text?: string;
  /** Nebeninfo (Ort, frühere Namen …) */
  meta?: string;
  areas: AreaId[];
  kind?: "normal" | "turning" | "now" | "future";
  media?: MediaId;
  /** Querverweis auf ein anderes Kapitel */
  link?: { to: string; label: string };
};

export const timeline: TimelineEntry[] = [
  { id: "t-2004-geburt", when: "2004", year: 2004, title: "Geburt in Berlin.", areas: ["familie"] },
  {
    id: "t-kita",
    when: "ca. 2006-2010",
    year: 2006,
    title: "Kita Johanna-Tesch-Straße",
    meta: "12439 Berlin · damals „Kita Drei Käse Hoch“",
    text: "Hier beginnen Freundschaften, die bis heute geblieben sind.",
    areas: ["kindheit"],
    media: "weg-kita",
    link: { to: "mein-umfeld", label: "Johannes, Finn & Felix" },
  },
  { id: "t-einschulung", when: "2010", year: 2010, title: "Einschulung mit 5 Jahren.", areas: ["kindheit"] },
  { id: "t-grundschule", when: "2010-2016", year: 2010.1, title: "Grundschule an der Alten Feuerwache", meta: "Berlin", areas: ["kindheit"] },
  { id: "t-basketball", when: "2010-2020", year: 2010.2, title: "Basketball beim Köpenick BBC 90", areas: ["kindheit"], media: "weg-basketball" },
  { id: "t-judo", when: "2010-2012", year: 2010.3, title: "Judo", meta: "Turnhalle der Schule an der Alten Feuerwache", areas: ["kindheit"] },
  { id: "t-malkurs", when: "2013-2016", year: 2013, title: "Malkurs im Kulturzentrum „Ratz-Fatz“", meta: "Niederschöneweide", areas: ["kindheit"] },
  { id: "t-motocross", when: "seit 2014", year: 2014, title: "Motocross beim MC Woltersdorf", areas: ["motorrad"], media: "weg-motocross-start" },
  { id: "t-ski", when: "2015-2020", year: 2015, title: "Skikurse in den Winterferien", areas: ["kindheit"] },
  {
    id: "t-gymnasium",
    when: "2016-2023",
    year: 2016,
    title: "Alexander-von-Humboldt-Gymnasium",
    meta: "Berlin · Klassenstufen 7-12 · die 11. Klasse einmal wiederholt",
    areas: ["kindheit"],
  },
  { id: "t-theater", when: "2016-2024", year: 2016.1, title: "Theater im Kulturzentrum Ratz-Fatz", areas: ["kindheit"] },
  { id: "t-graffiti", when: "2016", year: 2016.2, title: "Beginn mit Graffiti.", areas: ["graffiti"] },
  { id: "t-kegeln", when: "2018", year: 2018, title: "Kegelverein SV Lichtenberg 47", meta: "bis heute", areas: [] },
  { id: "t-badminton", when: "2018", year: 2018.1, title: "Badminton beim Köpenick Badminton Club e.V.", areas: [] },
  {
    id: "t-video",
    when: "2020",
    year: 2020,
    title: "Beginn mit Videoschnitt.",
    text: "Zunächst für YouTube, Streamer und Freunde.",
    areas: ["arbeit"],
    media: "weg-video-start",
  },
  {
    id: "t-wendepunkt",
    when: "2021",
    year: 2021,
    title: "Wendepunkt.",
    text: "2021 wurde ich aufgrund illegalen Graffitis von der Polizei gefasst. Gleichzeitig verlief auch meine schulische Laufbahn nicht wie vorgesehen und ich wiederholte die 11. Klasse. Rückblickend kamen damit zwei Situationen zusammen, die für mich einen Wendepunkt darstellten. Ich musste mich stärker damit auseinandersetzen, welche Konsequenzen meine eigenen Entscheidungen haben und welchen Weg ich in Zukunft einschlagen möchte.",
    areas: [],
    kind: "turning",
  },
  { id: "t-abitur", when: "2023", year: 2023, title: "Abitur.", areas: ["kindheit"], media: "weg-abitur" },
  {
    id: "t-legal",
    when: "2023",
    year: 2023.1,
    title: "Rückkehr zu Graffiti, jetzt legal.",
    text: "Die Leidenschaft ist geblieben. Mein Umgang damit hat sich verändert.",
    areas: ["graffiti"],
    media: "weg-legal",
  },
  {
    id: "t-fsj",
    when: "2023-2024",
    year: 2023.2,
    title: "FSJ in der Kita Helbigstraße",
    meta: "Berlin · früher „Kita Marktspatzen“",
    areas: ["ausbildung", "arbeit"],
    media: "weg-fsj",
    link: { to: "meine-entwicklung", label: "Warum FSJ?" },
  },
  { id: "t-ausbildung", when: "2024", year: 2024, title: "Beginn der Erzieherausbildung.", areas: ["ausbildung"] },
  {
    id: "t-gartenstadt",
    when: "2024-2027",
    year: 2024.1,
    title: "Ausbildung und Arbeit in der Kita Zur Gartenstadt",
    meta: "Berlin · früher „Kita Gartenstadtfrösche“",
    areas: ["ausbildung", "arbeit"],
  },
  {
    id: "t-strasse",
    when: "2024",
    year: 2024.2,
    title: "Erstes Straßenmotorrad.",
    text: "Zehn Jahre nach Beginn mit Motocross.",
    areas: ["motorrad"],
    media: "weg-strasse",
    link: { to: "meine-interessen", label: "Meine Garage" },
  },
  { id: "t-glazex", when: "2025", year: 2025, title: "Video Editor bei GlazeX e.V.", areas: ["arbeit"] },
  {
    id: "t-freelance",
    when: "2026",
    year: 2026,
    title: "Bezahlte Medienprojekte",
    text: "Zusätzlich freiberufliche Projekte für Vereine, YouTube und Events.",
    areas: ["arbeit"],
  },
  { id: "t-synchron", when: "2026", year: 2026.1, title: "Beginn mit Synchronsprechen.", areas: ["musik"] },
  {
    id: "t-heute",
    when: "2026 bis heute",
    year: 2026.2,
    title: "5. Semester der Erzieherausbildung.",
    text: "Aktuell verbinden sich:",
    areas: ["ausbildung"],
    kind: "now",
    media: "weg-heute",
  },
  {
    id: "t-2027",
    when: "2027",
    year: 2027,
    title: "Voraussichtlicher Abschluss der Erzieherausbildung im Sommer.",
    areas: ["ausbildung"],
    kind: "future",
  },
];

export const nowItems = [
  "Ausbildung",
  "pädagogische Arbeit",
  "Videoschnitt",
  "kleinere Freelance-Projekte",
  "Synchronsprechen",
  "Kunst / Graffiti",
  "Motocross / Motorrad",
  "Kegelsport",
];

export const future =
  "Ich weiß noch nicht genau, wohin mein Weg mich nach meiner Ausbildung führen wird. Und eigentlich finde ich das gar nicht schlimm. Ich möchte nicht alles im Voraus planen. Ich möchte möglichst viel erleben.";
