export const goalsHeadline = "Wo ich mich weiterentwickeln möchte.";

export type Goal = {
  id: string;
  nr: string;
  topic: string;
  goal: string;
  text: string;
  /** Querverweis auf den Bereich, aus dem das Ziel entstanden ist */
  origin: { to: string; label: string };
};

export const goals: Goal[] = [
  {
    id: "g-integration",
    nr: "01",
    topic: "Integration",
    goal: "Sicherer im Bereich Integration werden.",
    text: "Am Anfang war der Umgang mit Integrationskindern für mich teilweise mit Unsicherheit verbunden. Mittlerweile interessiert mich genau dieser Bereich besonders. Ich möchte während meiner Ausbildung mehr Erfahrungen sammeln und mich nach meinem Abschluss möglicherweise zum Integrationserzieher weiterqualifizieren.",
    origin: { to: "entw-integration", label: "Aus: Meine Entwicklung · Integration" },
  },
  {
    id: "g-rolle",
    nr: "02",
    topic: "Pädagogische Rolle",
    goal: "Meinen eigenen pädagogischen Stil weiterentwickeln.",
    text: "Ich habe einen eher lockeren und kumpelhaften Umgang mit Kindern und möchte diese Art auch nicht verlieren. Gleichzeitig möchte ich besser darin werden, Nähe, klare Grenzen und meine Verantwortung als pädagogische Fachkraft miteinander zu verbinden.",
    origin: { to: "entw-umgang", label: "Aus: Mein Umgang mit Kindern" },
  },
  {
    id: "g-feld",
    nr: "03",
    topic: "Arbeitsfeld",
    goal: "Herausfinden, wo ich später arbeiten möchte.",
    text: "Zu Beginn dachte ich vor allem an die Kita. Durch meine bisherigen Erfahrungen sind für mich inzwischen auch Hort und Jugendarbeit interessant geworden. Bis zum Ende meiner Ausbildung möchte ich weitere Erfahrungen sammeln, um besser einschätzen zu können, welcher Bereich langfristig zu mir passt.",
    origin: { to: "entw-felder", label: "Aus: Altersgruppen & Arbeitsfelder" },
  },
];
