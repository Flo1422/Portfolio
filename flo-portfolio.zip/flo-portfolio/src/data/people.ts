/**
 * MEIN UMFELD – Datengrundlage für die Verbindungskarte
 * ------------------------------------------------------------
 * REGELN
 * - Jede Person hat eine eindeutige ID (p-vorname-kontext).
 *   Gleiche Vornamen = eigene Einträge, bis Flo bestätigt, dass es dieselbe Person ist.
 * - `unconfirmed`: Hier gibt es eine gleichnamige Person in einem anderen Bereich.
 *   Die Seite behauptet KEINE Verbindung, bis `sameAs` gesetzt / die Einträge zusammengeführt sind.
 * - Wird die Identität bestätigt: beide Einträge zu einem zusammenführen
 *   (areas vereinen, eine ID löschen, Verweise anpassen).
 */

export type AreaId =
  | "familie"
  | "kindheit"
  | "freunde"
  | "graffiti"
  | "musik"
  | "motorrad"
  | "ausbildung"
  | "arbeit";

export type Area = { id: AreaId; label: string; color: string; note: string };

export const areas: Area[] = [
  { id: "familie", label: "Familie", color: "var(--c-familie)", note: "Direkte Familie, beide Seiten und Ziehfamilie." },
  { id: "kindheit", label: "Kindheit", color: "var(--c-kindheit)", note: "Kita, Schule, Verein, Theater." },
  { id: "freunde", label: "Freunde", color: "var(--c-freunde)", note: "Der enge Freundeskreis." },
  { id: "graffiti", label: "Graffiti", color: "var(--c-graffiti)", note: "Kreativszene seit ca. 2021." },
  { id: "musik", label: "Musik", color: "var(--c-musik)", note: "Musikvideos, Shows, Events." },
  { id: "motorrad", label: "Motorräder", color: "var(--c-motorrad)", note: "Enger und weiterer Motorradkreis." },
  { id: "ausbildung", label: "Ausbildung", color: "var(--c-ausbildung)", note: "FSJ und Berufsschule." },
  { id: "arbeit", label: "Arbeit", color: "var(--c-arbeit)", note: "Kita, Video- und Medienprojekte." },
];

export type Person = {
  id: string;
  name: string;
  /** Kurzbeschreibung – nur Fakten aus Flos Angaben */
  role: string;
  since?: string;
  areas: AreaId[];
  /** Unterkreis, z. B. "eng" / "weit" beim Motorrad */
  circle?: string;
  /** Kurze Wegbeschreibung der Verbindung (Schritte) */
  path?: string[];
  /** true = gleichnamige Person woanders, Identität NICHT bestätigt */
  unconfirmed?: boolean;
  /** Wichtige Knotenpunkte werden größer dargestellt */
  key?: boolean;
};

export const people: Person[] = [
  // ─── FAMILIE ───────────────────────────────────────────────
  { id: "p-simone", name: "Simone", role: "Mama", areas: ["familie"] },
  { id: "p-olaf", name: "Olaf", role: "Papa", areas: ["familie"] },
  { id: "p-kristian", name: "Kristian", role: "Jüngerer Bruder", areas: ["familie"] },
  { id: "p-jens", name: "Jens", role: "Onkel · Bruder von Papa", areas: ["familie"] },
  { id: "p-micky", name: "Micky", role: "Tante · Frau von Jens", areas: ["familie"] },
  { id: "p-lena", name: "Lena", role: "Cousine", areas: ["familie"] },
  { id: "p-joerg", name: "Jörg", role: "Onkel · Bruder von Mama", areas: ["familie"] },
  { id: "p-manuela", name: "Manuela", role: "Tante · Frau von Jörg", areas: ["familie"] },
  { id: "p-felix-cousin", name: "Felix", role: "Cousin", areas: ["familie"] },
  { id: "p-cedric", name: "Cedric", role: "Cousin", areas: ["familie"] },
  { id: "p-diana", name: "Diana", role: "Ziehmama", areas: ["familie"] },
  { id: "p-bjoern", name: "Björn", role: "Ziehpapa", areas: ["familie"] },
  { id: "p-florian-zieh", name: "Florian", role: "Ziehbruder", areas: ["familie"] },
  { id: "p-spike", name: "Spike", role: "Hund · Ziehfamilie", areas: ["familie"] },
  { id: "p-gary", name: "Gary", role: "Katze · Ziehfamilie", areas: ["familie"] },

  // ─── KINDHEIT ──────────────────────────────────────────────
  {
    id: "p-johannes",
    name: "Johannes",
    role: "Kindheitsfreund",
    since: "ca. 2007",
    areas: ["kindheit"],
    path: ["Kita", "Basketballverein"],
  },
  {
    id: "p-finn",
    name: "Finn",
    role: "Kindheitsfreund",
    since: "ca. 2007",
    areas: ["kindheit"],
    path: ["Kita", "Basketballverein"],
  },
  {
    id: "p-felix-kita",
    name: "Felix",
    role: "Kindheitsfreund · im FSJ zusammengearbeitet, heute Dozent an meiner Berufsschule",
    since: "ca. 2007",
    areas: ["kindheit", "ausbildung", "arbeit"],
    path: ["Kita", "Grundschule", "Gymnasium", "Theatergruppe", "FSJ, dort zusammengearbeitet", "Dozent an meiner Berufsschule"],
    key: true,
  },

  // ─── ENGER FREUNDESKREIS ───────────────────────────────────
  {
    id: "p-lasse",
    name: "Lasse",
    role: "Online über Rainbow Six Siege kennengelernt, später nach Berlin gezogen · fährt auch Motorrad",
    since: "2020",
    areas: ["freunde", "motorrad"],
    path: ["Videospiele", "Berlin", "größerer Freundeskreis"],
    key: true,
  },
  { id: "p-jerome-freunde", name: "Jerome", role: "Freundeskreis · fährt auch Motorrad", since: "ca. 2022", areas: ["freunde", "motorrad"], path: ["über Lasses Freundeskreis"] },
  { id: "p-pascal", name: "Pascal", role: "Freundeskreis · macht eigene Beats, auf die ich schon Texte geschrieben habe · fährt auch Motorrad", since: "ca. 2022", areas: ["freunde", "musik", "motorrad"], path: ["über Lasses Freundeskreis"] },
  { id: "p-peer-freunde", name: "Peer", role: "Freundeskreis · geht öfter mit mir Graffiti sprayen", since: "ca. 2022", areas: ["freunde", "graffiti"], path: ["über Lasses Freundeskreis"], unconfirmed: true },
  { id: "p-marc", name: "Marc", role: "Freundeskreis", since: "ca. 2022", areas: ["freunde"], path: ["über Lasses Freundeskreis"] },
  {
    id: "p-felix-gym",
    name: "Felix",
    role: "Vom Gymnasium, ich habe ihn in den Freundeskreis geholt",
    since: "2021",
    areas: ["freunde"],
    path: ["Gymnasium", "von mir in den Freundeskreis geholt"],
  },
  { id: "p-jamie", name: "Jamie", role: "Über Jerome kennengelernt · fährt auch Motorrad", since: "2023", areas: ["freunde", "motorrad"], path: ["über Jerome"] },

  // ─── ANTHONY ───────────────────────────────────────────────
  {
    id: "p-anthony",
    name: "Anthony",
    role: "Wichtiger Verbindungspunkt",
    since: "ca. 2022",
    areas: ["kindheit", "ausbildung", "graffiti", "freunde", "arbeit", "motorrad"],
    path: ["über Felix & die Theatergruppe", "gleiche FSJ-Einrichtung", "zurück zum Graffiti, jetzt legal", "Freundeskreis", "Empfehlung für meine heutige Kita", "zusammen Motorrad gefahren, seine KTM 690 SMC R gekauft"],
    key: true,
  },

  // ─── MOTORRAD · ENG (seit 2024) ────────────────────────────
  { id: "p-jason-moto", name: "Jason", role: "Enger Motorradkreis · auch außerhalb des Fahrens", since: "2024", areas: ["motorrad"], circle: "eng", unconfirmed: true },
  { id: "p-ben", name: "Ben", role: "Enger Motorradkreis · auch außerhalb des Fahrens", since: "2024", areas: ["motorrad"], circle: "eng" },
  { id: "p-basti", name: "Basti", role: "Enger Motorradkreis · auch außerhalb des Fahrens", since: "2024", areas: ["motorrad"], circle: "eng" },
  { id: "p-timo", name: "Timo", role: "Enger Motorradkreis · auch außerhalb des Fahrens", since: "2024", areas: ["motorrad"], circle: "eng" },
  { id: "p-malin", name: "Malin", role: "Enger Motorradkreis · auch außerhalb des Fahrens · zusammen mit Julian", areas: ["motorrad"], circle: "eng" },
  { id: "p-julian", name: "Julian", role: "Enger Motorradkreis · auch außerhalb des Fahrens · zusammen mit Malin", areas: ["motorrad"], circle: "eng" },

  // ─── MOTORRAD · WEIT ──────────────────────────────────────
  { id: "p-emil-moto", name: "Emil", role: "Motorradkreis", areas: ["motorrad"], circle: "weit", unconfirmed: true },
  {
    id: "p-jerome-moto",
    name: "Jerome",
    role: "Motorradkreis · Stuntfahrer für Luvre47",
    since: "2024",
    areas: ["motorrad", "graffiti", "musik"],
    circle: "weit",
    path: ["über Luvre47 kennengelernt", "Motorradkreis"],
  },
  { id: "p-jerry", name: "Jerry", role: "Motorradkreis · über Jerome", areas: ["motorrad"], circle: "weit" },
  { id: "p-john", name: "John", role: "Motorradkreis", areas: ["motorrad"], circle: "weit" },
  { id: "p-lars", name: "Lars", role: "Motorradkreis", areas: ["motorrad"], circle: "weit" },
  { id: "p-ron", name: "Ron", role: "Motorradkreis", areas: ["motorrad"], circle: "weit" },
  { id: "p-peer-moto", name: "Peer", role: "Motorradkreis · über Paul und Jerome", areas: ["motorrad"], circle: "weit", unconfirmed: true },
  { id: "p-robert", name: "Robert", role: "Motorradkreis", areas: ["motorrad"], circle: "weit" },
  { id: "p-hagen", name: "Hagen", role: "Motorradkreis", areas: ["motorrad"], circle: "weit" },
  { id: "p-paul-moto", name: "Paul", role: "Motorradkreis", areas: ["motorrad"], circle: "weit", unconfirmed: true },
  { id: "p-erik", name: "Erik", role: "Motorradkreis · über Jerry", areas: ["motorrad"], circle: "weit" },
  { id: "p-nils", name: "Nils", role: "Motorradkreis", areas: ["motorrad"], circle: "weit" },
  { id: "p-lennart", name: "Lennart", role: "Motorradkreis", areas: ["motorrad"], circle: "weit" },

  // ─── MOTORRAD · ÜBER ANTHONY ──────────────────────────────
  { id: "p-ole", name: "Ole", role: "Motorradkreis · über Anthony kennengelernt", areas: ["motorrad"], circle: "anthony", path: ["über Anthony"] },
  { id: "p-leo", name: "Leo", role: "Motorradkreis · über Anthony kennengelernt", areas: ["motorrad"], circle: "anthony", path: ["über Anthony"] },
  { id: "p-alex", name: "Alex", role: "Motorradkreis · über Anthony kennengelernt", areas: ["motorrad"], circle: "anthony", path: ["über Anthony"] },
  { id: "p-sasha", name: "Sasha", role: "Motorradkreis · über Anthony kennengelernt", areas: ["motorrad"], circle: "anthony", path: ["über Anthony"] },

  // ─── GRAFFITI / MUSIK / KREATIVSZENE ───────────────────────
  { id: "p-luvre47", name: "Luvre47", role: "Über Graffiti kennengelernt · Musik · Musikvideos", since: "ca. 2021", areas: ["graffiti", "musik", "arbeit"], key: true },
  { id: "p-bangs", name: "Bangs", role: "Über Graffiti kennengelernt · Rapper bei AOB (Army Of Brothers) · Musikvideos", since: "ca. 2021", areas: ["graffiti", "musik", "arbeit"] },
  { id: "p-almani", name: "Almani", role: "Über Graffiti kennengelernt · Rapper bei AOB (Army Of Brothers) · Musikvideos", since: "ca. 2021", areas: ["graffiti", "musik", "arbeit"] },
  { id: "p-haki", name: "Haki", role: "Über Graffiti kennengelernt · Rapper bei AOB (Army Of Brothers) · Musikvideos", since: "ca. 2021", areas: ["graffiti", "musik", "arbeit"] },
  { id: "p-chapo", name: "Chapo", role: "Über Graffiti kennengelernt · Rapper bei AOB (Army Of Brothers) · Musikvideos", since: "ca. 2021", areas: ["graffiti", "musik", "arbeit"] },
  { id: "p-tnf47", name: "TNF47", role: "Über Graffiti kennengelernt · Musik", since: "ca. 2021", areas: ["graffiti", "musik"] },
  { id: "p-felix-lobrecht", name: "Felix Lobrecht", role: "Über Graffiti kennengelernt", since: "ca. 2021", areas: ["graffiti"] },
  { id: "p-tighty", name: "Tighty", role: "Deutschrapper · Ben und ich sind Stuntfahrer für ihn und öfter zu seinen Musikvideo-Drehs eingeladen", areas: ["musik", "motorrad"], path: ["Motorrad-Stunts", "Musikvideo-Drehs"] },
  { id: "p-tom", name: "Tom", role: "Fotograf · über die Kreativszene", since: "2024", areas: ["graffiti", "musik"] },
  { id: "p-jordan", name: "Jordan", role: "Fotograf · über die Kreativszene", since: "2024", areas: ["graffiti", "musik"] },

  // ─── BERUFSSCHULE ─────────────────────────────────────────
  { id: "p-emil-schule", name: "Emil", role: "Berufsschule · Arbeitskollege von Paul", since: "2024", areas: ["ausbildung"], unconfirmed: true },
  { id: "p-paul-schule", name: "Paul", role: "Berufsschule · Arbeitskollege von Emil", since: "2024", areas: ["ausbildung"], unconfirmed: true },
  { id: "p-jason-schule", name: "Jason", role: "Berufsschule", since: "2024", areas: ["ausbildung"], unconfirmed: true },
  {
    id: "p-linus",
    name: "Linus",
    role: "Im FSJ kennengelernt und zusammengearbeitet · Arbeitskollege von Anthony und Felix · seit Sommer 2026 in meiner Klasse",
    since: "2023/24",
    areas: ["ausbildung", "arbeit"],
    path: ["FSJ 2023/24, zusammengearbeitet", "gleiche Berufsschule, andere Stufe", "Sommer 2026: gleiche Klasse"],
  },
];

/** Direkte Person-zu-Person-Verbindungen (zusätzlich zu den Bereichen) */
export type Relation = { from: string; to: string; label: string };

export const relations: Relation[] = [
  { from: "p-johannes", to: "p-finn", label: "Kita & Basketball" },
  { from: "p-felix-kita", to: "p-anthony", label: "Theatergruppe" },
  { from: "p-lasse", to: "p-jerome-freunde", label: "über Lasse" },
  { from: "p-lasse", to: "p-pascal", label: "über Lasse" },
  { from: "p-lasse", to: "p-peer-freunde", label: "über Lasse" },
  { from: "p-lasse", to: "p-marc", label: "über Lasse" },
  { from: "p-jerome-freunde", to: "p-jamie", label: "über Jerome" },
  { from: "p-malin", to: "p-julian", label: "ein Paar" },
  { from: "p-jerry", to: "p-jason-moto", label: "Geschwister" },
  { from: "p-tighty", to: "p-ben", label: "Ben & ich: Stuntfahrer in seinen Musikvideos" },
  { from: "p-paul-moto", to: "p-peer-moto", label: "über Paul" },
  { from: "p-jerome-moto", to: "p-peer-moto", label: "über Jerome" },
  { from: "p-jerome-moto", to: "p-jerry", label: "über Jerome" },
  { from: "p-jerry", to: "p-erik", label: "über Jerry" },
  { from: "p-paul-schule", to: "p-emil-schule", label: "Arbeitskollegen · gleiche Einrichtung" },
  // Mein enger Motorradkreis – auch abseits vom Fahren unterwegs (Malin & Julian bewusst nicht verbunden)
  { from: "p-jason-moto", to: "p-ben", label: "enger Kreis · auch abseits vom Motorrad" },
  { from: "p-jason-moto", to: "p-basti", label: "enger Kreis · auch abseits vom Motorrad" },
  { from: "p-jason-moto", to: "p-timo", label: "enger Kreis · auch abseits vom Motorrad" },
  { from: "p-ben", to: "p-basti", label: "enger Kreis · auch abseits vom Motorrad" },
  { from: "p-ben", to: "p-timo", label: "enger Kreis · auch abseits vom Motorrad" },
  { from: "p-basti", to: "p-timo", label: "enger Kreis · auch abseits vom Motorrad" },
  // Über Anthony
  { from: "p-anthony", to: "p-ole", label: "über Anthony" },
  { from: "p-anthony", to: "p-leo", label: "über Anthony" },
  { from: "p-anthony", to: "p-alex", label: "über Anthony" },
  { from: "p-anthony", to: "p-sasha", label: "über Anthony" },
  { from: "p-ole", to: "p-leo", label: "Geschwister" },
  { from: "p-linus", to: "p-anthony", label: "Arbeitskollegen" },
  { from: "p-linus", to: "p-felix-kita", label: "Arbeitskollegen · im FSJ zusammen" },
  // AOB – Army Of Brothers
  { from: "p-haki", to: "p-bangs", label: "AOB · Army Of Brothers" },
  { from: "p-bangs", to: "p-almani", label: "AOB · Army Of Brothers" },
  { from: "p-almani", to: "p-chapo", label: "AOB · Army Of Brothers" },
  { from: "p-chapo", to: "p-haki", label: "AOB · Army Of Brothers" },
  { from: "p-haki", to: "p-almani", label: "AOB · Army Of Brothers" },
  { from: "p-bangs", to: "p-chapo", label: "AOB · Army Of Brothers" },
  { from: "p-luvre47", to: "p-jerome-moto", label: "Stuntfahrer für Luvre47" },
  // OFFEN: Laut Brief half Anthony, „Jerome, den ich über Luvre47 kannte“, in den
  // Freundeskreis zu integrieren. Welcher Jerome gemeint ist, ist noch zu klären.
];

/** Geschichten = hervorgehobene Pfade durch das Netzwerk */
export type Story = { id: string; title: string; steps: string[]; highlight: string[]; text?: string };

export const stories: Story[] = [
  {
    id: "s-kreis",
    title: "Der Kreis schließt sich",
    steps: ["Kita", "Grundschule", "Gymnasium", "Theater", "FSJ", "Dozent"],
    highlight: ["p-felix-kita", "kindheit", "ausbildung"],
    text: "Felix kenne ich seit ungefähr 2007 aus der Kita. Heute ist er Dozent an meiner Berufsschule.",
  },
  {
    id: "s-anthony",
    title: "Anthony verbindet",
    steps: ["Felix", "Theater", "Anthony", "FSJ", "Graffiti", "Freunde", "Arbeit", "Motorräder"],
    highlight: ["p-felix-kita", "p-anthony", "ausbildung", "graffiti", "freunde", "arbeit", "motorrad", "p-ole", "p-leo", "p-alex", "p-sasha"],
    text: "Anthony kannte ich über Felix und die Theatergruppe. Danach: gleiche FSJ-Einrichtung, zurück zum Graffiti (jetzt legal) und die Empfehlung für die Kita, in der ich heute arbeite. Auch beim Motorrad: Wir sind zusammen gefahren, ich habe ihm seine KTM 690 SMC R abgekauft, und über ihn kenne ich Ole, Leo, Alex und Sasha.",
  },
  {
    id: "s-graffiti",
    title: "Von der Wand zum Video",
    steps: ["Graffiti", "Freundschaften", "Musik", "Musikvideos", "Shows & Events", "Video / Medien"],
    highlight: ["graffiti", "musik", "arbeit", "p-luvre47", "p-bangs", "p-almani", "p-haki", "p-chapo", "p-tnf47"],
    text: "Mehrere Menschen, die ich über Graffiti kennengelernt habe, machen Musik. Haki, Bangs, Almani und Chapo zum Beispiel sind die Rap-Crew AOB (Army Of Brothers). Dadurch wurde ich zu Musikvideos, Shows und Events eingeladen.",
  },
  {
    id: "s-lasse",
    title: "Aus einem Spiel wird ein Freundeskreis",
    steps: ["Rainbow Six Siege", "Lasse", "Berlin", "Freundeskreis"],
    highlight: ["p-lasse", "freunde", "p-jerome-freunde", "p-pascal", "p-peer-freunde", "p-marc", "p-jamie"],
    text: "Lasse habe ich 2020 online über Videospiele kennengelernt. Später zog er nach Berlin und durch ihn kam ich in einen größeren Freundeskreis.",
  },
  {
    id: "s-linus",
    title: "Linus",
    steps: ["FSJ 2023/24, zusammengearbeitet", "Arbeitskollege von Anthony & Felix", "gleiche Berufsschule", "Sommer 2026: gleiche Klasse"],
    highlight: ["p-linus", "ausbildung", "arbeit", "p-anthony", "p-felix-kita"],
  },
];

export const umfeldOutro = [
  "Wenn ich mein Umfeld betrachte, merke ich, wie stark sich unterschiedliche Abschnitte meines Lebens überschneiden. Aus einem gemeinsamen Hobby wurden Freundschaften, aus Freundschaften entstanden neue Interessen und manche Menschen haben sogar meinen beruflichen Weg beeinflusst.",
  "Einige begleiten mich bereits seit meiner Kindheit, andere sind erst vor wenigen Jahren dazugekommen. Zusammen bilden sie das Umfeld, das mich bis heute begleitet und geprägt hat.",
];
