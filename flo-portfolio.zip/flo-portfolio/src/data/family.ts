/**
 * FAMILIENBAUM
 * Bewusst KEIN biologisch vollständiger Stammbaum:
 * Es erscheinen nur Menschen, die für Flo zur Familie gehören.
 * Die Ziehfamilie ist ein gleichwertiger Zweig.
 * `personId` verweist auf people.ts.
 */

/** pet = Haustier (wird in einer eigenen Reihe des Zweigs gezeigt) */
export type FamilyMember = { personId: string; name: string; role: string; generation: 0 | 1; isMe?: boolean; pet?: "Hund" | "Katze" };

export type FamilyBranch = {
  id: string;
  label: string;
  note?: string;
  /** Wo der Zweig an die Kernfamilie andockt */
  attachTo?: string;
  /** Generation 0 = Eltern-/Onkel-Ebene, 1 = Flos Ebene */
  members: FamilyMember[];
  /** Paare (werden verbunden) */
  couples?: [string, string][];
  /** Kinder eines Paares / Elternteils */
  children?: { parents: string[]; kids: string[] }[];
};

export const familyHeadline = "Familie ist mehr als ein Stammbaum.";

export const family: FamilyBranch[] = [
  {
    id: "fam-vaeterlich",
    label: "Väterliche Seite",
    attachTo: "p-olaf",
    members: [
      { personId: "p-jens", name: "Jens", role: "Onkel · Bruder von Papa", generation: 0 },
      { personId: "p-micky", name: "Micky", role: "Tante · Frau von Jens", generation: 0 },
      { personId: "p-lena", name: "Lena", role: "Cousine", generation: 1 },
    ],
    couples: [["p-jens", "p-micky"]],
    // Lena wird bewusst NICHT mit einem Elternteil verbunden (Lenas Vater wird nicht dargestellt).
  },
  {
    id: "fam-kern",
    label: "Direkte Familie",
    members: [
      { personId: "p-olaf", name: "Olaf", role: "Papa", generation: 0 },
      { personId: "p-simone", name: "Simone", role: "Mama", generation: 0 },
      { personId: "flo", name: "Flo", role: "Ich", generation: 1, isMe: true },
      { personId: "p-kristian", name: "Kristian", role: "Jüngerer Bruder", generation: 1 },
    ],
    couples: [["p-olaf", "p-simone"]],
    children: [{ parents: ["p-olaf", "p-simone"], kids: ["flo", "p-kristian"] }],
  },
  {
    id: "fam-muetterlich",
    label: "Mütterliche Seite",
    attachTo: "p-simone",
    members: [
      { personId: "p-joerg", name: "Jörg", role: "Onkel · Bruder von Mama", generation: 0 },
      { personId: "p-manuela", name: "Manuela", role: "Tante · Frau von Jörg", generation: 0 },
      { personId: "p-felix-cousin", name: "Felix", role: "Cousin", generation: 1 },
      { personId: "p-cedric", name: "Cedric", role: "Cousin", generation: 1 },
    ],
    couples: [["p-joerg", "p-manuela"]],
    // Eltern-Kind-Linien nur dort, wo Flo sie ausdrücklich angegeben hat.
  },
  {
    id: "fam-zieh",
    label: "Ziehfamilie",
    attachTo: "flo",
    note: "Gehört genauso dazu.",
    members: [
      { personId: "p-diana", name: "Diana", role: "Ziehmama", generation: 0 },
      { personId: "p-bjoern", name: "Björn", role: "Ziehpapa", generation: 0 },
      { personId: "p-florian-zieh", name: "Florian", role: "Ziehbruder", generation: 1 },
      { personId: "p-spike", name: "Spike", role: "Hund", generation: 1, pet: "Hund" },
      { personId: "p-gary", name: "Gary", role: "Katze", generation: 1, pet: "Katze" },
    ],
    couples: [["p-diana", "p-bjoern"]],
  },
];
