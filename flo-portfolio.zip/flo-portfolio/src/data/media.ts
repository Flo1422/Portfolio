/**
 * BILD-SLOTS
 * ------------------------------------------------------------
 * Jede Stelle der Website, an der ein Foto stehen soll, hat hier
 * einen Slot. Solange `src` leer ist, zeigt die Seite einen
 * beschrifteten Platzhalter mit dem `hint`.
 *
 * Foto einbauen:
 *   1. Datei nach /public/media/ legen (z. B. hero-01.jpg, ideal ≤ 1600 px, WebP/JPG)
 *   2. hier `src: "/media/hero-01.jpg"` eintragen
 *   3. `alt` sinnvoll beschreiben (für Screenreader)
 *
 * Optional: `focus` = CSS object-position (z. B. "50% 30%").
 */

export type MediaSlot = {
  src?: string;
  alt: string;
  hint: string;
  focus?: string;
};

const slot = (hint: string, alt = hint): MediaSlot => ({ hint, alt });
const photo = (src: string, alt: string, focus?: string): MediaSlot => ({ src, alt, hint: alt, focus });

/** Eingebaute Fotos (einmal definiert, an mehreren Stellen nutzbar) */
export const photos = {
  portrait: photo("/media/portrait-sonnenuntergang.jpg", "Flo im Sonnenuntergang mit weißer Cap und Sonnenbrille", "50% 40%"),
  graffitiDose: photo("/media/graffiti-dose.jpg", "Flo hält eine rote Sprühdose in die Kamera, dahinter eine bunte Wand", "50% 30%"),
  drehTighty: photo("/media/dreh-tighty.jpg", "Nachts beim Musikvideo-Dreh für Tighty: Ben und Flo auf Motorrädern", "50% 45%"),
  schrauben: photo("/media/schrauben.jpg", "Die Jungs und ich beim Schrauben an einem Motorrad", "50% 55%"),
  bewegungsbaustelle: photo("/media/bewegungsbaustelle.jpg", "Ein Haus aus Kisten, Reifen und Brettern, gebaut mit den Kindern in der Bewegungsbaustelle", "50% 55%"),
  crossen: photo("/media/crossen-varg.jpg", "Flo beim Crossen im Wald auf der Stark VARG", "40% 50%"),
  videoschnitt: photo("/media/videoschnitt.jpg", "Schnitt des Musikvideos „U7 Freestyle“ von Luvre47 in Premiere Pro", "50% 35%"),
  stilOutfit: photo("/media/stil-outfit.jpg", "Flo von hinten im Trikot mit Kirschblüten-Print, weiße Cap, vor blühenden Bäumen", "50% 40%"),
  helmPeace: photo("/media/helm-peace.jpg", "Flo mit Motocross-Helm und Brille auf dem Motorrad, Peace-Zeichen vor blauem Himmel", "50% 45%"),
  portraitFeuer: photo("/media/portrait-feuer.jpg", "Flo nachts am Feuer, mit schwarzer Cap und Jacke", "55% 35%"),
  openair: photo("/media/hinterm-block-openair-2025.jpg", "Vorbereitung für das Hinterm Block Open Air 2025: Autos vor Graffiti-Wänden", "50% 40%"),
};

export const media = {
  // HERO-COLLAGE (Tiefenebenen)
  "hero-01": photos.portrait,
  "hero-02": photos.crossen,
  "hero-03": photos.graffitiDose,
  "hero-04": photos.schrauben,
  "hero-05": photos.videoschnitt,
  "hero-06": photos.drehTighty,
  "hero-07": photos.openair,
  "hero-08": photos.bewegungsbaustelle,

  // MENÜ-VORSCHAUEN
  "menu-ueber-mich": slot("Menü-Vorschau: Porträt"),
  "menu-mein-weg": slot("Menü-Vorschau: altes Kinder-/Jugendfoto"),
  "menu-mein-umfeld": slot("Menü-Vorschau: Gruppenfoto"),
  "menu-meine-interessen": slot("Menü-Vorschau: Motorrad oder Graffiti"),
  "menu-meine-entwicklung": slot("Menü-Vorschau: Kita / Ausbildung"),
  "menu-meine-lernziele": slot("Menü-Vorschau: ruhiges Stimmungsbild"),

  // ÜBER MICH
  "about-portrait": photos.portraitFeuer,
  "about-portrait-2": photos.helmPeace,
  "about-style": photos.stilOutfit,

  // MEIN WEG
  "weg-kita": slot("Kinderfoto (Kita-Zeit)"),
  "weg-basketball": slot("Basketball Köpenick BBC 90"),
  "weg-motocross-start": slot("Erste Motocross-Jahre, KTM SX-F 50"),
  "weg-graffiti-start": slot("Graffiti · frühe Phase (nur wenn unproblematisch)"),
  "weg-video-start": slot("Erste Schnittprojekte"),
  "weg-abitur": slot("Abitur 2023"),
  "weg-legal": slot("Legale Wand 2023"),
  "weg-fsj": slot("FSJ · Kita Helbigstraße (ohne erkennbare Kinder)"),
  "weg-strasse": slot("Erstes Straßenmotorrad 2024"),
  "weg-heute": slot("Heute · aktuelles Foto"),

  // UMFELD
  "umfeld-gruppe": slot("Gruppenfoto Freundeskreis"),

  // ENTWICKLUNG
  "entw-kita": slot("Kita-Johanna-Tesch-Straße (Gebäude / Außenansicht)"),

  // ABSCHLUSS
  "outro": slot("Abschlussbild · Weg, Straße, Horizont"),
} satisfies Record<string, MediaSlot>;

export type MediaId = keyof typeof media;
