import type { MediaId } from "./media";

export const chapters = [
  { id: "ueber-mich", nr: "01", label: "Über mich", preview: "menu-ueber-mich", teaser: "Wer ich bin." },
  { id: "mein-weg", nr: "02", label: "Mein Weg", preview: "menu-mein-weg", teaser: "2004 bis heute." },
  { id: "mein-umfeld", nr: "03", label: "Mein Umfeld", preview: "menu-mein-umfeld", teaser: "Menschen, die mich prägen." },
  { id: "meine-interessen", nr: "04", label: "Meine Interessen", preview: "menu-meine-interessen", teaser: "Bauen, malen, schneiden." },
  { id: "meine-entwicklung", nr: "05", label: "Meine Entwicklung", preview: "menu-meine-entwicklung", teaser: "Meinen Platz finden." },
  { id: "meine-lernziele", nr: "06", label: "Meine Lernziele", preview: "menu-meine-lernziele", teaser: "Wohin ich wachsen will." },
] as const satisfies ReadonlyArray<{ id: string; nr: string; label: string; preview: MediaId; teaser: string }>;

export type ChapterId = (typeof chapters)[number]["id"];

export const hero = {
  name: "FLO.",
  sub: ["Ein persönliches Portfolio", "Berlin · 2026"],
  claim: "Alles hängt zusammen.",
  words: ["Menschen.", "Kunst.", "Bewegung.", "Erfahrungen.", "Kreativität."],
  after: "Das ist meine Welt.",
  collage: ["hero-01", "hero-02", "hero-03", "hero-04", "hero-05", "hero-06", "hero-07", "hero-08"] as MediaId[],
  fragments: [
    { year: "2004", text: "Berlin." },
    { year: "2007", text: "Freundschaften, die geblieben sind." },
    { year: "2014", text: "Motocross." },
    { year: "2016", text: "Graffiti." },
    { year: "2020", text: "Videoschnitt." },
    { year: "2021", text: "Wendepunkt." },
    { year: "2023", text: "Abitur · FSJ · legales Graffiti." },
    { year: "2024", text: "Erzieherausbildung · Supermoto." },
    { year: "2026", text: "Noch lange nicht fertig." },
  ],
};

export const about = {
  headline: "Hey, ich bin Flo.",
  facts: [
    { label: "Name", value: "Florian, meistens Flo." },
    { label: "Geboren", value: "November 2004 in Berlin" },
    { label: "Aufgewachsen", value: "Berlin Treptow-Köpenick" },
    { label: "Gerade", value: "5. Semester Erzieherausbildung" },
  ],
  // Persönlicher Text – in Absätzen
  text: [
    "Ich bin Florian, meistens einfach Flo. Ich bin in Berlin Treptow-Köpenick aufgewachsen. Ich würde mich als offenen, kreativen und empathischen Menschen beschreiben, der grundsätzlich erstmal versucht, jedem Menschen unvoreingenommen zu begegnen.",
    "Ich habe eine eher ruhige Art, bin gleichzeitig aber fast immer für Spaß zu haben und nehme selten ein Blatt vor den Mund. Wenn mich etwas wirklich begeistert, kann ich mich extrem darin verlieren und viel Zeit und Energie investieren. Wenn diese Begeisterung allerdings fehlt, sieht das manchmal ganz anders aus. Dann neige ich dazu, Dinge aufzuschieben oder mir den einfachsten Weg zum Ziel zu suchen.",
    "Ich interessiere mich für unglaublich viele unterschiedliche Dinge. Motorräder und Autos gehören genauso dazu wie Graffiti, Kunst, Musik, Videoschnitt, Sport und Videospiele. Vieles davon verbindet für mich Kreativität mit der Möglichkeit, mich auszuprobieren und meinen eigenen Stil zu entwickeln.",
    "Besonders wichtig sind mir Fairness und Gleichwertigkeit. Gleichzeitig möchte ich mein Leben nicht nur nach einem festen Plan abarbeiten. Ich möchte möglichst viel erleben, unterschiedliche Erfahrungen sammeln und später auf eine Zeit zurückblicken können, die nicht nur aus Alltag bestanden hat.",
  ],
  traits: ["kreativ", "offen", "sportlich", "freundlich", "empathisch", "offenherzig", "stilbewusst", "eher ruhig", "fast immer für Spaß zu haben", "sehr direkt"],
  core: ["Kreativität", "Offenheit", "Empathie", "Fairness"],
  values: [
    // Notizen nur aus Flos eigenen Formulierungen übernommen
    { word: "Fairness", note: "Besonders wichtig." },
    { word: "Gleichwertigkeit", note: "Kinder sollen für mich grundsätzlich gleichwertig dazugehören." },
    { word: "Erleben", note: "Nicht nur nach einem festen Plan abarbeiten." },
  ],
  imperfect: [
    {
      title: "100 % oder 20 %",
      text: "Wenn mich etwas wirklich interessiert, kann ich extrem viel Energie hineinstecken. Fehlt mir die Begeisterung, fällt mir Motivation deutlich schwerer.",
    },
    {
      title: "Der einfachste Weg",
      text: "Ich suche häufig nach dem effizientesten bzw. einfachsten Weg. Manchmal ist das clever, manchmal einfach Faulheit.",
    },
    {
      title: "Kein Blatt vor dem Mund",
      text: "Ich bin sehr direkt und offen. Gleichzeitig lerne ich, dass direkte Kommunikation nicht in jeder Situation automatisch die beste Kommunikation ist.",
    },
  ],
  interests: ["Motorräder", "Autos", "Graffiti", "Video", "Musik", "Sport", "Gaming", "Kunst"],
  style:
    "Kleidung, Motorräder, Kunst, Musik oder die Gestaltung eines Videos: Ästhetik spielt für mich in vielen Bereichen eine Rolle. Ich mag Dinge, die einen eigenen Charakter haben, und entwickle dabei gerne meinen eigenen Stil.",
};

export const outro = {
  headline: "Was kommt danach?",
  lines: ["Ausbildung abschließen.", "Weitere Erfahrungen sammeln.", "Herausfinden, wo mein Platz ist."],
  closer: "Der Rest ergibt sich auf dem Weg.",
  footer: "Flo · Portfolio 2026",
};
