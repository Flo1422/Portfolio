import type { MediaSlot } from "./media";

const ph = (hint: string): MediaSlot => ({ hint, alt: hint });

/* ═══════════════════ MOTORRÄDER ═══════════════════ */

export const motoIntro = {
  headline: "Gebaut, nicht gekauft.",
  fascination: ["Motorradfahren", "Stunts", "Schrauben", "Technik", "Customizing", "individuelle Motorräder", "1-of-1-Bikes"],
  text: [
    "Mich fasziniert am Motorradfahren deutlich mehr als nur das Fahren selbst. Ich interessiere mich für Stunts, Technik, Schrauben und vor allem dafür, Motorräder nach meinen eigenen Vorstellungen umzubauen.",
    "Besonders reizt mich die Idee, aus einem normalen Motorrad ein 1-of-1-Bike zu machen. Etwas, das meinen eigenen Stil widerspiegelt und so kein zweites Mal existiert.",
  ],
  punchline: "Der einzige Haken: Die Kacke ist verdammt teuer.",
};

export type Bike = {
  id: string;
  make: string;
  model: string;
  /** Kapitel in Flos Geschichte */
  chapter: string;
  story: string;
  /** Zusatzinfos – später ergänzen (Umbauten, Erinnerungen …). Nichts erfinden. */
  details: { label: string; value: string }[];
  photos: MediaSlot[];
};

export const bikes: Bike[] = [
  {
    id: "bike-sxf50",
    make: "KTM",
    model: "SX-F 50",
    chapter: "Der Anfang",
    story: "Als kleines Kind auf der Motocross-Strecke.",
    details: [
      { label: "Einsatz", value: "Motocross" },
      { label: "Verein", value: "MC Woltersdorf" },
    ],
    photos: [ph("KTM SX-F 50 · Kinderfoto auf der Strecke"), ph("KTM SX-F 50 · zweites Foto")],
  },
  {
    id: "bike-690",
    make: "KTM",
    model: "690 SMC R",
    chapter: "Auf die Straße",
    story: "Von Anthony gekauft. Mein Einstieg ins Straßen- und Supermoto-Fahren.",
    details: [
      { label: "Einsatz", value: "Straße / Supermoto" },
      { label: "Status", value: "Nach einem Unfall ersetzt" },
    ],
    photos: [ph("KTM 690 SMC R · Seitenansicht"), ph("KTM 690 SMC R · Fahrt"), ph("KTM 690 SMC R · Detail")],
  },
  {
    id: "bike-sxf250",
    make: "KTM",
    model: "SX-F 250",
    chapter: "Zurück ins Gelände",
    story: "Später von Erik gekauft.",
    details: [{ label: "Einsatz", value: "Motocross" }],
    photos: [ph("KTM SX-F 250 · Strecke"), ph("KTM SX-F 250 · Detail")],
  },
  {
    id: "bike-varg",
    make: "Stark",
    model: "VARG SM",
    chapter: "Neu gedacht",
    story: "Nach dem Unfall mit der KTM 690 SMC R gekauft.",
    details: [{ label: "Einsatz", value: "Supermoto" }],
    photos: [ph("Stark VARG SM · Seitenansicht"), ph("Stark VARG SM · Umbauten / Details")],
  },
];

/* ═══════════════════ GRAFFITI ═══════════════════ */

export const graffiti = {
  headline: "Alles kann eine Leinwand sein.",
  facts: [
    { k: "Motiv", v: "Hauptsächlich Buchstaben und Zahlen. Characters fallen mir deutlich schwerer." },
    { k: "Skizzen", v: "Normalerweise keine. Die Arbeiten entstehen spontan aus dem Handgelenk, während des Malens." },
    { k: "Fläche", v: "Kunst muss nicht auf Papier oder einer klassischen Leinwand stattfinden. Eine Wand oder ein Ort kann ebenfalls Leinwand sein." },
  ],
  meaning: [
    "Mich fasziniert Kunst auf großen Flächen. Mir gefällt außerdem, dass nicht jede Ecke einer Stadt gleich aussieht.",
    "Graffiti kann für mich auch eine kreative Form sein, sich mit Stadtentwicklung und Themen wie Gentrifizierung auseinanderzusetzen.",
  ],
  today: "Heute gehört für mich dazu, rechtliche Grenzen ernst zu nehmen und legale Flächen zu nutzen.",
  phases: [
    { year: "2016", label: "Angefangen." },
    { year: "2021", label: "Konsequenzen." },
    { year: "2023", label: "Legal zurückgekehrt." },
    { year: "Heute", label: "Leidenschaft geblieben, Umgang verändert." },
  ],
  /** Wandgalerie – beliebig viele Einträge. `caption` optional (Ort/Jahr). */
  wall: [
    { photo: { src: "/media/wand-prozess.jpg", alt: "Flo sprüht an einer roten Wand", hint: "", focus: "40% 40%" }, ratio: "1143 / 1600", caption: "" },
    { photo: { src: "/media/wand-unterfuehrung.jpg", alt: "Großes Piece in Blau und Lila auf rotem Hintergrund in einer Unterführung", hint: "" }, ratio: "4 / 3", caption: "" },
    { photo: { src: "/media/wand-jerome.jpg", alt: "Piece in Grau und Schwarz auf einer Mauer, oben rechts „Jerome“, für Jerome gemalt", hint: "" }, ratio: "4 / 3", caption: "" },
    { photo: { src: "/media/wand-aktion-painting.jpg", alt: "Rosa-gelbes Piece unter dem Schriftzug „Aktion Painting“", hint: "" }, ratio: "904 / 487", caption: "" },
    { photo: { src: "/media/wand-hustle.jpg", alt: "Digitale Zeichnung: Schriftzug „Hustle“ in Bubble-Letters über einer schlafenden Comicfigur auf Geldscheinen", hint: "" }, ratio: "1131 / 1600", caption: "" },
  ],

};

/* ═══════════════════ VIDEO ═══════════════════ */

export const video = {
  headline: "Schnitt für Schnitt.",
  tools: [
    { name: "Adobe Premiere Pro", use: "Schnitt" },
    { name: "Adobe After Effects", use: "Motion & Effekte" },
    { name: "Blender", use: "3D-Animationen" },
  ],
  favorites: ["Musikvideos", "Dokumentationen von Tagen", "Events", "Stream-Highlights", "private Motorrad-Zusammenschnitte"],
  /**
   * Spuren der „Timeline“ – jede Phase ist ein Clip.
   * Position (`at`, `len`) ist nur die REIHENFOLGE auf einer abstrakten Zeitachse (0–100),
   * keine Jahresangabe. `year` nur dort, wo Flo ein Jahr genannt hat.
   */
  clips: [
    { id: "v-gaming", track: 0, at: 0, len: 26, year: "2020", label: "Gaming & Streaming", names: ["Witheball", "Minimichegga", "KeTo"] },
    { id: "v-youtube", track: 1, at: 18, len: 26, label: "Größere YouTube-Kanäle", names: ["u. a. MAX · ca. 1 Mio. Abonnenten"] },
    { id: "v-musik", track: 2, at: 36, len: 30, label: "Musikvideos", names: ["Luvre47", "AOB (Army Of Brothers): Haki, Chapo, Bangs, Almani"] },
    { id: "v-vereine", track: 1, at: 62, len: 38, year: "2025", label: "Gaming-Vereine", names: ["GlazeX e.V. · Video Editor"] },
    { id: "v-freelance", track: 0, at: 80, len: 20, year: "2026", label: "Freelance", names: ["Vereine, YouTube, Events"] },
    { id: "v-moto", track: 2, at: 74, len: 26, label: "Privat", names: ["Motorrad-Zusammenschnitte"] },
  ],
  trackNames: ["V1", "V2", "V3"],
  rulerStart: "2020",
  rulerEnd: "Heute",
  statement: [
    "Ich habe nicht „das eine Projekt“, auf das ich unglaublich stolz bin.",
    "Videoschnitt ist für mich inzwischen vor allem eine Fähigkeit, die ich über mehrere Jahre aufgebaut habe und mit der ich nebenbei Geld verdienen kann.",
  ],
};

/* ═══════════════════ MUSIK & STIMME ═══════════════════ */

export const voice = {
  headline: "Worte & Stimme.",
  music: "Ich mache selbst nicht ernsthaft Musik. Manchmal schreibe ich Texte, aus Freude daran, Reime zu bauen, Texte zu schreiben und eine Message unterzubringen. Einige davon habe ich auf Beats von Passi geschrieben, einem Freund, der selbst Beats baut.",
  musicPoints: ["Reime bauen", "Texte schreiben", "eine Message unterbringen"],
  dub: "Mit Synchronsprechen habe ich angefangen, weil mir häufig gesagt wurde, dass ich eine passende Stimme dafür habe. Seit 2026 habe ich erste Sprecherrollen.",
  dubPoints: ["Projekte für Vereine wie GlazeX", "sehr kleine Rollen für Animes"],
  dubNote: "Konkrete Projekte kann ich teilweise nicht öffentlich zeigen.",
};

/* ═══════════════════ SPORT ═══════════════════ */

/**
 * from: Startjahr (null = unbekannt, nur „heute“ bekannt)
 * to:   Endjahr (null = bis heute)
 * today: wie es heute aussieht
 */
export type Sport = { id: string; name: string; from: number | null; to: number | null; note?: string; today?: string };

export const sportIntro = "Sport begleitet mich seit meiner Kindheit, aber die Sportarten haben sich verändert.";

/** to: null = bis heute. Fußball hat keine Jahresangabe und wird separat gezeigt. */
export const sports: Sport[] = [
  { id: "sp-basketball", name: "Basketball", from: 2010, to: 2020, note: "Köpenick BBC 90" },
  { id: "sp-judo", name: "Judo", from: 2010, to: 2012 },
  { id: "sp-motocross", name: "Motocross", from: 2014, to: null, note: "MC Woltersdorf", today: "bis heute" },
  { id: "sp-ski", name: "Ski", from: 2015, to: 2020, note: "regelmäßig in den Winterferien", today: "gerne gelegentlich im Winterurlaub" },
  { id: "sp-badminton", name: "Badminton", from: 2018, to: 2018, note: "Köpenick Badminton Club e.V." },
  { id: "sp-kegeln", name: "Kegeln", from: 2018, to: null, note: "SV Lichtenberg 47", today: "bis heute" },
  { id: "sp-gym", name: "Fitnessstudio", from: null, to: null, today: "gelegentlich" },
];
export const sportExtra = "Fußball: eher Vergangenheit und Freizeit.";

/* ═══════════════════ GAMING ═══════════════════ */

export const gaming = {
  headline: "Hinter den Kulissen.",
  games: ["CS:GO", "Valorant", "Rainbow Six Siege"],
  text: [
    "Früher war Gaming wichtiger als heute, vor allem Ego-Shooter.",
    "Über Rainbow Six Siege habe ich zum Beispiel Lasse online kennengelernt. Gaming war dadurch nicht nur Unterhaltung, sondern führte zu realen Freundschaften.",
    "Heute spiele ich deutlich weniger, weil andere Hobbys wichtiger geworden sind. Trotzdem arbeite ich weiterhin mit Gaming-Vereinen zusammen, im Medien- und Videobereich.",
  ],
  closer: "Heute häufiger hinter den Kulissen als selbst vor dem Bildschirm.",
};

/* ═══════════════════ ROTER FADEN ═══════════════════ */

export const interestsThread = {
  lead: "Meine Interessen wirken auf den ersten Blick sehr unterschiedlich.",
  core: "Ein roter Faden ist aber: Ich möchte Dinge gestalten und ihnen meinen eigenen Stil geben.",
  objects: ["ein Motorrad", "eine Wand", "ein Video", "ein Text"],
};
