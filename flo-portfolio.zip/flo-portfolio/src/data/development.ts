export const development = {
  headline: "Meinen Platz finden.",
  intro: "Nicht „früher schlecht, heute perfekt“, sondern durch Erfahrungen herausfinden, welche pädagogischen Bereiche zu mir passen könnten.",

  /** Stationen des Weges – der Pfad wächst beim Scrollen durch diese Punkte */
  stations: [
    {
      id: "d-praktikum",
      when: "9. Klasse",
      title: "Erstes Kita-Praktikum",
      place: "Kita Johanna-Tesch-Straße, meine eigene frühere Kita.",
      text: [
        "Dadurch wurde der Erzieherberuf für mich erstmals wirklich interessant.",
        "Das Praktikum war aber zu kurz, um beurteilen zu können, ob ich diesen Beruf langfristig machen möchte.",
      ],
      motif: ["Kita-Kind", "Schülerpraktikant", "Erzieherausbildung"],
    },
    {
      id: "d-fsj",
      when: "2023",
      title: "FSJ",
      place: "Kita Helbigstraße, Berlin",
      text: [
        "Nach dem Abitur war ich mir noch unsicher. Über Menschen, die mir wichtig sind, insbesondere Anthony und Felix, bekam ich die Möglichkeit für ein FSJ.",
        "Ich wollte den Beruf länger ausprobieren, bevor ich mich für eine Ausbildung entscheide. Außerdem erhielt ich ein kleines Taschengeld und konnte ein Jahr lang praktische Erfahrung sammeln, ohne mich sofort langfristig festzulegen.",
        "Im FSJ lernte ich sowohl U3 als auch Ü3 kennen.",
      ],
      result: ["Die Arbeit macht mir Spaß.", "Ich möchte die Ausbildung machen."],
    },
    {
      id: "d-ausbildung",
      when: "seit 2024",
      title: "Erzieherausbildung",
      place: "Kita Zur Gartenstadt, Berlin",
      text: [
        "Während des FSJ fand ich Krippenkinder zunächst besonders interessant. Während meiner Ausbildung arbeite ich überwiegend mit Ü3-Kindern und habe gemerkt: Die Arbeit mit älteren Kindern fällt mir leichter.",
      ],
    },
  ],

  approach: {
    title: "Mein Umgang mit Kindern",
    text: [
      "Ich war schon immer eher kumpelhaft im Umgang mit Kindern.",
      "Gleichzeitig war mir von Anfang an wichtig, keine Unterschiede aufgrund von Herkunft oder Einschränkungen zu machen.",
    ],
    statement: "Kinder sollen für mich grundsätzlich gleichwertig dazugehören.",
  },

  integration: {
    title: "Integration",
    steps: ["Unsicherheit", "Erfahrung", "Interesse", "Mögliche Spezialisierung"],
    text: [
      "Zu Beginn war ich im Umgang mit Integrationskindern teilweise unsicher. Mir fehlten Erfahrung und Wissen.",
      "Mittlerweile hat sich das verändert. Gerade dieser Bereich interessiert mich heute besonders.",
      "Langfristig möchte ich mich nach der Ausbildung möglicherweise zum Integrationserzieher weiterqualifizieren.",
    ],
  },

  /** Die Verzweigung */
  branches: [
    {
      id: "b-elementar",
      label: "Elementarbereich",
      text: "Mein Alltag in der Ausbildung: überwiegend Ü3. Krippe ist nicht ausgeschlossen, aber ältere Kinder scheinen mir aktuell eher zu liegen.",
    },
    {
      id: "b-hort",
      label: "Hort",
      text: "Durch mein Praktikum an einer Grundschule / im Hort wurde eine weitere Möglichkeit sichtbar. Ich kann mir inzwischen auch die Arbeit mit Grundschulkindern vorstellen.",
    },
    {
      id: "b-jugend",
      label: "Jugendarbeit",
      text: "Interessiert mich seit ungefähr einem halben Jahr zunehmend, durch Erzählungen anderer und durch die Berufsschule, in der wir zuletzt verstärkt Jugendarbeit behandelt haben.",
    },
  ],
  openQuestion: "Ob ich langfristig in einer Kita bleibe, weiß ich noch nicht.",

  core: "Meine bisherigen Erfahrungen haben mir nicht unbedingt gezeigt, wo ich später arbeiten werde. Sie haben mir vielmehr gezeigt, dass der Erzieherberuf deutlich mehr Möglichkeiten bietet, als ich zu Beginn meiner Ausbildung gedacht habe.",
};
