/** Sehr dezente Film-Körnung – ein statisches SVG-Rauschen, leicht versetzt animiert */
export function Grain() {
  return <div className="grain" aria-hidden="true" />;
}
