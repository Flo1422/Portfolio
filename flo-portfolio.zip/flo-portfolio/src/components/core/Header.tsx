"use client";
import { useState } from "react";
import { Magnetic } from "./Magnetic";
import { Menu } from "./Menu";
import { useScroll } from "./SmoothScroll";

export function Header() {
  const [open, setOpen] = useState(false);
  const { scrollTo } = useScroll();
  return (
    <>
      <header className="site-header">
        <a
          href="#top"
          className="logo"
          aria-label="FLO, zurück zum Anfang"
          onClick={(e) => {
            e.preventDefault();
            scrollTo(0 as unknown as HTMLElement);
          }}
        >
          FLO<span className="signal">°</span>
        </a>
        <Magnetic>
          <button
            className="menu-btn"
            aria-expanded={open}
            aria-controls="hauptmenue"
            onClick={() => setOpen((o) => !o)}
            data-cursor={open ? "SCHLIESSEN" : "ÖFFNEN"}
          >
            <span className="menu-btn-label">{open ? "Schließen" : "Menü"}</span>
            <span className="menu-btn-icon" aria-hidden="true" data-open={open}>
              <i />
              <i />
            </span>
          </button>
        </Magnetic>
      </header>
      <Menu open={open} onClose={() => setOpen(false)} />
    </>
  );
}
