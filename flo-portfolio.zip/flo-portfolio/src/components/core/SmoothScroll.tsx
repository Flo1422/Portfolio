"use client";
import Lenis from "lenis";
import { createContext, useContext, useEffect, useRef, type ReactNode } from "react";
import { gsap, ScrollTrigger } from "@/lib/gsap";

type Ctx = { scrollTo: (target: string | number | HTMLElement, opts?: { immediate?: boolean }) => void; stop: () => void; start: () => void };
const ScrollCtx = createContext<Ctx>({ scrollTo: () => {}, stop: () => {}, start: () => {} });
export const useScroll = () => useContext(ScrollCtx);

export function SmoothScroll({ children }: { children: ReactNode }) {
  const lenisRef = useRef<Lenis | null>(null);

  useEffect(() => {
    // Nach dem Laden der Schriften alle Scroll-Positionen neu messen
    document.fonts?.ready.then(() => ScrollTrigger.refresh());
    const t = setTimeout(() => ScrollTrigger.refresh(), 800);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) return;
    const lenis = new Lenis({ lerp: 0.1, wheelMultiplier: 1, smoothWheel: true });
    lenisRef.current = lenis;
    lenis.on("scroll", ScrollTrigger.update);
    const tick = (t: number) => lenis.raf(t * 1000);
    gsap.ticker.add(tick);
    gsap.ticker.lagSmoothing(0);
    return () => {
      gsap.ticker.remove(tick);
      lenis.destroy();
      lenisRef.current = null;
    };
  }, []);

  const api: Ctx = {
    scrollTo: (target, opts) => {
      const el = typeof target === "string" ? document.querySelector<HTMLElement>(target) : target;
      if (el === null) return;
      if (lenisRef.current) lenisRef.current.scrollTo(el as HTMLElement | number, { immediate: opts?.immediate, force: true });
      else if (typeof el === "number") window.scrollTo({ top: el });
      else el.scrollIntoView();
    },
    stop: () => lenisRef.current?.stop(),
    start: () => lenisRef.current?.start(),
  };

  return <ScrollCtx.Provider value={api}>{children}</ScrollCtx.Provider>;
}
