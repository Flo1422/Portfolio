"use client";
import { useRef, type ElementType } from "react";
import { gsap, useGSAP, MQ } from "@/lib/gsap";

type Props = {
  lines: string[];
  as?: ElementType;
  className?: string;
  /** Verzögerung zwischen Zeilen */
  stagger?: number;
  /** Start des ScrollTriggers */
  start?: string;
  id?: string;
};

/**
 * Überschrift, deren Zeilen beim Erreichen aus einer Maske gleiten.
 * Ohne JS / bei reduced motion: normal sichtbar.
 */
export function MaskText({ lines, as: Tag = "h2", className = "", stagger = 0.09, start = "top 85%", id }: Props) {
  const ref = useRef<HTMLElement>(null);
  useGSAP(
    () => {
      const mm = gsap.matchMedia();
      mm.add(MQ.motion, () => {
        const spans = ref.current!.querySelectorAll(".mask > span");
        gsap.fromTo(
          spans,
          { yPercent: 140, rotate: 2.5 },
          {
            yPercent: 0,
            rotate: 0,
            duration: 1.25,
            stagger,
            scrollTrigger: { trigger: ref.current, start, once: true },
          },
        );
      });
    },
    { scope: ref },
  );
  return (
    <Tag ref={ref} className={className} id={id}>
      {lines.map((l, i) => (
        <span className="mask" key={i}>
          <span>{l}</span>
        </span>
      ))}
    </Tag>
  );
}
