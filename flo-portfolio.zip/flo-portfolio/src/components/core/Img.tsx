import { media, type MediaId, type MediaSlot } from "@/data/media";
import styles from "./Img.module.css";

type Props = {
  slot: MediaId | MediaSlot;
  className?: string;
  /** eager nur für das Allererste im Viewport */
  eager?: boolean;
  sizes?: string;
  style?: React.CSSProperties;
};

/**
 * Bild-Slot. Ohne hinterlegte Datei erscheint ein klar beschrifteter Platzhalter.
 */
export function Img({ slot, className = "", eager, style }: Props) {
  const m: MediaSlot = typeof slot === "string" ? media[slot] : slot;
  if (m.src) {
    return (
      <div className={`${styles.frame} ${className}`} style={style}>
        <img
          src={m.src}
          alt={m.alt}
          loading={eager ? "eager" : "lazy"}
          decoding="async"
          style={{ objectPosition: m.focus }}
          className={styles.img}
        />
      </div>
    );
  }
  return (
    <div style={style} className={`${styles.frame} ${styles.placeholder} ${className}`} role="img" aria-label={`Platzhalter: ${m.hint}`}>
      <span className={styles.phLabel}>
        <span className={styles.phTag}>Foto folgt</span>
        {m.hint}
      </span>
    </div>
  );
}
