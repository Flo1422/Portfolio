"use client";
import { useRef } from "react";
import { gsap, useGSAP, MQ } from "@/lib/gsap";

/** Kapitelkopf: Nummer · Name · Linie, die sich zieht */
export function ChapterHead({ nr, label }: { nr: string; label: string }) {
  const ref = useRef<HTMLDivElement>(null);
  useGSAP(
    () => {
      gsap.matchMedia().add(MQ.motion, () => {
        gsap.from(".rule", { scaleX: 0, duration: 1.6, scrollTrigger: { trigger: ref.current, start: "top 90%", once: true } });
        gsap.from(".meta", { y: 12, opacity: 0, stagger: 0.08, duration: 0.8, scrollTrigger: { trigger: ref.current, start: "top 90%", once: true } });
      });
    },
    { scope: ref },
  );
  return (
    <div className="chapter-head" ref={ref}>
      <span className="meta nr">{nr} / 06</span>
      <span className="meta">{label}</span>
      <span className="rule" aria-hidden="true" />
    </div>
  );
}
