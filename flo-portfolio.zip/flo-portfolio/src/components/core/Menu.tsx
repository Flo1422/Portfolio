"use client";
import { useEffect, useRef, useState } from "react";
import { chapters } from "@/data/site";
import { gsap } from "@/lib/gsap";
import { Img } from "./Img";
import { useScroll } from "./SmoothScroll";

/**
 * Fullscreen-Menü. Hover/Fokus zeigt eine Bildvorschau des Bereichs.
 * Klick → Vorhang-Übergang → Sprung ins Kapitel.
 */
export function Menu({ open, onClose }: { open: boolean; onClose: () => void }) {
  const root = useRef<HTMLDivElement>(null);
  const curtain = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(0);
  const [curtainLabel, setCurtainLabel] = useState("");
  const { scrollTo, stop, start } = useScroll();
  const reduce = useRef(false);

  useEffect(() => {
    reduce.current = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }, []);

  // Öffnen / Schließen
  useEffect(() => {
    const el = root.current;
    if (!el) return;
    const items = el.querySelectorAll(".menu-item-inner");
    const metas = el.querySelectorAll(".menu-fade");
    if (open) {
      stop();
      el.hidden = false;
      document.body.style.overflow = "hidden";
      if (reduce.current) return;
      gsap.timeline()
        .fromTo(el, { clipPath: "inset(0 0 100% 0)" }, { clipPath: "inset(0 0 0% 0)", duration: 0.9, ease: "expo.inOut" })
        .fromTo(items, { yPercent: 140 }, { yPercent: 0, stagger: 0.05, duration: 1 }, "-=0.35")
        .fromTo(metas, { opacity: 0 }, { opacity: 1, duration: 0.6 }, "-=0.8");
      (el.querySelector(".menu-link") as HTMLElement | null)?.focus({ preventScroll: true });
    } else if (!el.hidden) {
      start();
      document.body.style.overflow = "";
      if (reduce.current) {
        el.hidden = true;
        return;
      }
      gsap.to(el, {
        clipPath: "inset(100% 0 0% 0)",
        duration: 0.7,
        ease: "expo.inOut",
        onComplete: () => {
          el.hidden = true;
        },
      });
    }
  }, [open, start, stop]);

  // Escape
  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [open, onClose]);

  const go = (id: string, label: string) => {
    const target = `#${id}`;
    if (reduce.current || !curtain.current) {
      onClose();
      requestAnimationFrame(() => scrollTo(target, { immediate: true }));
      return;
    }
    setCurtainLabel(label);
    const c = curtain.current;
    gsap
      .timeline()
      .set(c, { display: "flex", yPercent: 100 })
      .to(c, { yPercent: 0, duration: 0.75, ease: "expo.inOut" })
      .add(() => {
        root.current!.hidden = true;
        document.body.style.overflow = "";
        start();
        onClose();
        scrollTo(target, { immediate: true });
      })
      .fromTo(c.querySelector(".curtain-label"), { yPercent: 140 }, { yPercent: 0, duration: 0.6 }, "-=0.35")
      .to(c, { yPercent: -100, duration: 0.85, ease: "expo.inOut", delay: 0.15 })
      .set(c, { display: "none" });
  };

  return (
    <>
      <div id="hauptmenue" ref={root} className="menu" hidden role="dialog" aria-modal="true" aria-label="Hauptmenü">
        <div className="menu-previews" aria-hidden="true">
          {chapters.map((c, i) => (
            <div key={c.id} className="menu-preview" data-active={i === active}>
              <Img slot={c.preview} />
            </div>
          ))}
          <span className="menu-bignr display">{chapters[active].nr}</span>
        </div>
        <nav className="menu-nav" aria-label="Kapitel">
          <ol>
            {chapters.map((c, i) => (
              <li key={c.id} className="menu-item">
                <a
                  href={`#${c.id}`}
                  className="menu-link"
                  data-active={i === active}
                  data-cursor="ÖFFNEN"
                  onMouseEnter={() => setActive(i)}
                  onFocus={() => setActive(i)}
                  onClick={(e) => {
                    e.preventDefault();
                    go(c.id, c.label);
                  }}
                >
                  <span className="mask">
                    <span className="menu-item-inner">
                      <span className="menu-nr meta">{c.nr}</span>
                      <span className="menu-label display">{c.label}</span>
                    </span>
                  </span>
                  <span className="menu-teaser serif">{c.teaser}</span>
                </a>
              </li>
            ))}
          </ol>
        </nav>
        <div className="menu-foot menu-fade">
          <span className="meta">Flo · Portfolio 2026</span>
          <span className="meta">Berlin</span>
          <span className="meta">Alles hängt zusammen.</span>
        </div>
      </div>
      <div ref={curtain} className="curtain" aria-hidden="true">
        <span className="mask">
          <span className="curtain-label display">{curtainLabel}</span>
        </span>
      </div>
    </>
  );
}
