"use client";
import { useEffect, useRef, useState } from "react";
import { chapters } from "@/data/site";
import { ScrollTrigger } from "@/lib/gsap";
import { useScroll } from "./SmoothScroll";

/**
 * Der rote Faden: feine Linie mit sechs Knoten am linken Rand (Desktop),
 * dünner Fortschrittsbalken oben (Mobile).
 */
export function Thread() {
  const fill = useRef<HTMLDivElement>(null);
  const bar = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<number[]>([]);
  const [current, setCurrent] = useState(-1);
  const { scrollTo } = useScroll();

  useEffect(() => {
    const measure = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      setPos(
        chapters.map((c) => {
          const el = document.getElementById(c.id);
          return el ? Math.min(1, el.offsetTop / max) : 0;
        }),
      );
    };
    measure();
    const t = setTimeout(measure, 1200);
    window.addEventListener("resize", measure);
    const st = ScrollTrigger.create({
      start: 0,
      end: "max",
      onUpdate: (self) => {
        const p = self.progress;
        if (fill.current) fill.current.style.transform = `scaleY(${p})`;
        if (bar.current) bar.current.style.transform = `scaleX(${p})`;
        let cur = -1;
        chapters.forEach((c) => {
          const el = document.getElementById(c.id);
          if (el && el.getBoundingClientRect().top < window.innerHeight * 0.5) cur++;
        });
        setCurrent(cur);
      },
    });
    ScrollTrigger.addEventListener("refresh", measure);
    return () => {
      clearTimeout(t);
      window.removeEventListener("resize", measure);
      ScrollTrigger.removeEventListener("refresh", measure);
      st.kill();
    };
  }, []);

  return (
    <>
      <div className="thread" aria-hidden="false">
        <div className="thread-track">
          <div className="thread-fill" ref={fill} />
          {chapters.map((c, i) => (
            <button
              key={c.id}
              className="thread-node"
              style={{ top: `${(pos[i] ?? i / 6) * 100}%` }}
              data-on={i <= current}
              data-current={i === current}
              onClick={() => scrollTo(`#${c.id}`)}
              aria-label={`Zu Kapitel ${c.nr}: ${c.label}`}
            >
              <span className="thread-label meta">
                {c.nr} {c.label}
              </span>
            </button>
          ))}
        </div>
      </div>
      <div className="progress" aria-hidden="true">
        <div ref={bar} />
      </div>
    </>
  );
}
