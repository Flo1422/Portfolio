"use client";
import { useEffect, useRef, useState } from "react";
import { video } from "@/data/interests";
import { MaskText } from "@/components/core/MaskText";
import { ScrollTrigger } from "@/lib/gsap";
import s from "./Interests.module.css";

/**
 * Video: angelehnt an eine Schnitt-Timeline (ohne Programm-Oberfläche zu kopieren).
 * Der Playhead folgt dem Scroll – oder wird gezogen / per Pfeiltasten bewegt.
 */
export function Video() {
  const root = useRef<HTMLDivElement>(null);
  const area = useRef<HTMLDivElement>(null);
  const [p, setP] = useState(4);
  const dragging = useRef(false);
  const manual = useRef(false);

  useEffect(() => {
    const st = ScrollTrigger.create({
      trigger: area.current,
      start: "top 80%",
      end: "bottom 25%",
      onUpdate: (self) => {
        if (!manual.current) setP(Math.round((2 + self.progress * 96) * 10) / 10);
      },
    });
    return () => st.kill();
  }, []);

  const fromPointer = (clientX: number) => {
    const r = area.current!.getBoundingClientRect();
    const x = Math.max(0, Math.min(1, (clientX - r.left) / r.width));
    setP(Math.round(x * 1000) / 10);
  };

  const active = video.clips.filter((c) => p >= c.at && p <= c.at + c.len);
  const current = active.sort((a, b) => b.at - a.at)[0];

  return (
    <div ref={root} className={s.video} id="i-video">
      <div className={s.vHead}>
        <span className="meta signal">Video / Videoschnitt</span>
        <MaskText lines={["Schnitt", "für Schnitt."]} className={`${s.bigHead} display`} />
      </div>

      <div className={s.vGrid}>
        {/* Monitor */}
        <div className={s.monitor} aria-live="polite">
          <div className={s.monitorScreen}>
            <span className={`${s.rec} meta`}>● {current?.year ?? ""}</span>
            {current ? (
              <>
                <span className={`${s.monitorLabel} display`}>{current.label}</span>
                <span className={s.monitorNames}>{current.names.join(" · ")}</span>
              </>
            ) : (
              <span className={`${s.monitorLabel} display`}>…</span>
            )}
          </div>
          <div className={s.monitorBar}>
            <span className="meta">Programm</span>
            <span className="meta">{String(Math.round(p)).padStart(2, "0")}:00</span>
          </div>
        </div>

        {/* Werkzeuge & Lieblingsformate */}
        <div className={s.vSide}>
          <div>
            <span className="meta">Werkzeuge</span>
            <ul className={s.tools}>
              {video.tools.map((t) => (
                <li key={t.name}>
                  <strong>{t.name}</strong>
                  <span>{t.use}</span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <span className="meta">Am liebsten schneide ich</span>
            <ul className={s.favs}>
              {video.favorites.map((f) => (
                <li key={f}>{f}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Timeline */}
      <div className={s.timelineBox}>
        <div className={s.ruler} aria-hidden="true">
          <span>{video.rulerStart}</span>
          <span>{video.rulerEnd}</span>
        </div>
        <div
          ref={area}
          className={s.tracks}
          data-cursor="ZIEHEN"
          onPointerDown={(e) => {
            dragging.current = true;
            manual.current = true;
            (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
            fromPointer(e.clientX);
          }}
          onPointerMove={(e) => dragging.current && fromPointer(e.clientX)}
          onPointerUp={() => (dragging.current = false)}
        >
          {video.trackNames.map((t, i) => (
            <div key={t} className={s.track}>
              <span className={`${s.trackName} meta`}>{t}</span>
              {video.clips
                .filter((c) => c.track === i)
                .map((c) => (
                  <div
                    key={c.id}
                    className={s.clip}
                    data-on={active.includes(c)}
                    style={{ left: `${c.at}%`, width: `${c.len}%` }}
                  >
                    <span>{c.label}</span>
                  </div>
                ))}
            </div>
          ))}
          <div
            className={s.playhead}
            style={{ left: `${p}%` }}
            role="slider"
            tabIndex={0}
            aria-label="Zeitachse"
            aria-valuemin={0}
            aria-valuemax={100}
            aria-valuenow={Math.round(p)}
            aria-valuetext={current ? current.label : ""}
            onKeyDown={(e) => {
              if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
                e.preventDefault();
                manual.current = true;
                setP((v) => Math.max(0, Math.min(100, v + (e.key === "ArrowRight" ? 4 : -4))));
              }
            }}
          />
        </div>
        <p className={`${s.vHint} meta`}>Playhead ziehen oder einfach weiterscrollen</p>
      </div>

      <div className={s.statement}>
        <p className={`${s.statementLead} serif`}>{video.statement[0]}</p>
        <p>{video.statement[1]}</p>
      </div>
    </div>
  );
}
