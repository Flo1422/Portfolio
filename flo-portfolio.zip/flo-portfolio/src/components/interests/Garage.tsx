"use client";
import { useRef, useState } from "react";
import { bikes, motoIntro } from "@/data/interests";
import { Img } from "@/components/core/Img";
import { MaskText } from "@/components/core/MaskText";
import { gsap, useGSAP, MQ } from "@/lib/gsap";
import s from "./Interests.module.css";

/** MEINE GARAGE – Bike-Auswahl, Fotos, Details */
export function Garage() {
  const root = useRef<HTMLDivElement>(null);
  const [idx, setIdx] = useState(0);
  const [photo, setPhoto] = useState(0);
  const bike = bikes[idx];

  const choose = (i: number) => {
    if (i === idx) return;
    setIdx(i);
    setPhoto(0);
  };

  // Wechsel-Animation der Bühne
  useGSAP(
    () => {
      gsap.matchMedia().add(MQ.motion, () => {
        gsap.fromTo(`.${s.stageMain}`, { clipPath: "inset(0 100% 0 0)" }, { clipPath: "inset(0 0% 0 0)", duration: 1.1, ease: "expo.inOut" });
        gsap.fromTo(`.${s.stageModel} > span`, { yPercent: 140 }, { yPercent: 0, duration: 1, delay: 0.15 });
        gsap.fromTo(`.${s.specs} > div`, { opacity: 0, x: 16 }, { opacity: 1, x: 0, stagger: 0.06, duration: 0.7, delay: 0.3 });
      });
    },
    { scope: root, dependencies: [idx], revertOnUpdate: false },
  );

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown" || e.key === "ArrowRight") {
      e.preventDefault();
      const n = (idx + 1) % bikes.length;
      choose(n);
      (root.current?.querySelectorAll<HTMLElement>('[role="tab"]')[n])?.focus();
    }
    if (e.key === "ArrowUp" || e.key === "ArrowLeft") {
      e.preventDefault();
      const n = (idx - 1 + bikes.length) % bikes.length;
      choose(n);
      (root.current?.querySelectorAll<HTMLElement>('[role="tab"]')[n])?.focus();
    }
  };

  return (
    <div className={s.moto} id="i-motorraeder">
      <div className={s.motoIntro}>
        <span className="meta signal">Motorräder</span>
        <MaskText lines={["Gebaut,", "nicht gekauft."]} className={`${s.bigHead} display`} />
        <div className={s.motoText}>
          {motoIntro.text.map((t, i) => (
            <p key={i}>{t}</p>
          ))}
          <p className={`${s.punch} serif`}>{motoIntro.punchline}</p>
        </div>
        <ul className={s.fascination} aria-label="Was mich fasziniert">
          {motoIntro.fascination.map((f) => (
            <li key={f}>{f}</li>
          ))}
        </ul>
      </div>

      <div ref={root} className={s.garage}>
        <div className={s.garageHead}>
          <h3 className="display">Meine Garage</h3>
          <span className="meta">
            {String(idx + 1).padStart(2, "0")} / {String(bikes.length).padStart(2, "0")}
          </span>
        </div>
        <div className={s.garageGrid}>
          <div className={s.bikeList} role="tablist" aria-label="Motorrad wählen" aria-orientation="vertical" onKeyDown={onKey}>
            {bikes.map((b, i) => (
              <button
                key={b.id}
                role="tab"
                id={`tab-${b.id}`}
                aria-selected={i === idx}
                aria-controls="garage-stage"
                tabIndex={i === idx ? 0 : -1}
                className={s.bikeTab}
                onClick={() => choose(i)}
                data-cursor="ÖFFNEN"
              >
                <span className="meta">{b.chapter}</span>
                <span className={s.bikeName}>
                  <small>{b.make}</small> {b.model}
                </span>
              </button>
            ))}
          </div>

          <div className={s.stage} id="garage-stage" role="tabpanel" aria-labelledby={`tab-${bike.id}`}>
            <div className={s.stageMain} data-cursor="ANSEHEN">
              <Img slot={bike.photos[photo]} className={s.stageImg} />
            </div>
            {bike.photos.length > 1 && (
              <div className={s.thumbs} aria-label="Fotos">
                {bike.photos.map((p, i) => (
                  <button key={i} aria-pressed={i === photo} aria-label={`Foto ${i + 1}: ${p.hint}`} onClick={() => setPhoto(i)}>
                    <Img slot={p} />
                  </button>
                ))}
              </div>
            )}
            <div className={s.stageInfo}>
              <h4 className={`${s.stageModel} display`}>
                <span>
                  {bike.make} {bike.model}
                </span>
              </h4>
              <p className={`${s.stageStory} serif`}>{bike.story}</p>
              <dl className={s.specs}>
                {bike.details.map((d) => (
                  <div key={d.label}>
                    <dt className="meta">{d.label}</dt>
                    <dd>{d.value}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
