"use client";
import { ChapterHead } from "@/components/core/ChapterHead";
import { MaskText } from "@/components/core/MaskText";
import { Garage } from "./Garage";
import { Wall } from "./Wall";
import { Video } from "./Video";
import { Voice } from "./Voice";
import { Sport } from "./Sport";
import { Gaming } from "./Gaming";
import { RedThread } from "./RedThread";
import s from "./Interests.module.css";

const INDEX = [
  { id: "i-motorraeder", label: "Motorräder" },
  { id: "i-graffiti", label: "Graffiti" },
  { id: "i-video", label: "Video" },
  { id: "i-musik", label: "Musik & Stimme" },
  { id: "i-sport", label: "Sport" },
  { id: "i-gaming", label: "Gaming" },
];

export function Interests() {
  return (
    <section id="meine-interessen" className={`${s.interests} chapter`} aria-labelledby="int-title">
      <div className="wrap">
        <ChapterHead nr="04" label="Meine Interessen" />
        <div className={s.head}>
          <MaskText id="int-title" lines={["Bauen.", "Malen.", "Schneiden."]} className={`${s.title} display`} />
          <nav aria-label="Interessen">
            <ol className={s.index}>
              {INDEX.map((x, i) => (
                <li key={x.id}>
                  <a href={`#${x.id}`} data-cursor="ÖFFNEN">
                    <span className="meta">0{i + 1}</span>
                    <span>{x.label}</span>
                  </a>
                </li>
              ))}
            </ol>
          </nav>
        </div>
        <Garage />
      </div>
      <Wall />
      <div className="wrap">
        <Video />
        <Voice />
        <Sport />
        <Gaming />
        <RedThread />
      </div>
    </section>
  );
}
