"use client";
import { useRef } from "react";
import { sports, sportIntro, sportExtra } from "@/data/interests";
import { gsap, useGSAP, MQ } from "@/lib/gsap";
import s from "./Interests.module.css";

const START = 2010;
const NOW = 2026.8;
const pos = (y: number) => ((y - START) / (NOW - START)) * 100;

/** Sport als Zeitbalken – die Sportarten wechseln, Bewegung bleibt */
export function Sport() {
  const root = useRef<HTMLDivElement>(null);
  useGSAP(
    () => {
      gsap.matchMedia().add(MQ.motion, () => {
        gsap.fromTo(`.${s.sBar}`, { scaleX: 0 }, {
          scaleX: 1,
          stagger: 0.12,
          ease: "power2.out",
          scrollTrigger: { trigger: root.current, start: "top 80%", end: "center 55%", scrub: 0.8 },
        });
      });
    },
    { scope: root },
  );
  const years = [2010, 2014, 2018, 2022, 2026];
  return (
    <div ref={root} className={s.sport} id="i-sport">
      <div className={s.sportHead}>
        <span className="meta signal">Sport</span>
        <h3 className={`${s.midHead} display`}>In Bewegung.</h3>
        <p className="serif">{sportIntro}</p>
      </div>
      <div className={s.sChart}>
        <div className={s.sAxis} aria-hidden="true">
          {years.map((y) => (
            <span key={y} style={{ left: `${pos(y)}%` }}>
              {y === 2026 ? "heute" : y}
            </span>
          ))}
        </div>
        <ul>
          {sports.map((sp) => {
            const from = sp.from ?? NOW - 0.4;
            const to = sp.to ?? NOW;
            const w = Math.max(pos(to) - pos(from), 1.4);
            const text = sp.from === null ? `heute ${sp.today}` : `${sp.from}${sp.to === sp.from ? "" : sp.to ? `-${sp.to}` : " bis heute"}`;
            return (
              <li key={sp.id} className={s.sRow} tabIndex={0}>
                <span className={s.sName}>{sp.name}</span>
                <span className={s.sLane}>
                  {sp.from !== null ? (
                    <span className={s.sBar} data-open={sp.to === null} style={{ left: `${pos(from)}%`, width: `${w}%` }} />
                  ) : (
                    <span className={s.sDot} style={{ left: `${pos(NOW) - 0.8}%` }} />
                  )}
                  {sp.today && sp.to !== null && sp.from !== null && (
                    <span className={s.sLater} style={{ left: `${pos(sp.to)}%`, width: `${pos(NOW) - pos(sp.to)}%` }} />
                  )}
                </span>
                <span className={`${s.sMeta} meta`}>
                  {text}
                  {sp.note ? ` · ${sp.note}` : ""}
                  {sp.today && sp.from !== null ? ` · heute ${sp.today}` : ""}
                </span>
              </li>
            );
          })}
        </ul>
        <p className={`${s.note} meta`}>{sportExtra}</p>
      </div>
    </div>
  );
}
