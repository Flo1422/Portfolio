"use client";
import { useEffect, useRef, useState } from "react";
import { interestsThread } from "@/data/interests";
import { gsap, useGSAP, MQ } from "@/lib/gsap";
import s from "./Interests.module.css";

const TARGETS = ["#i-motorraeder", "#i-graffiti", "#i-video", "#i-musik"];

/** Abschluss der Interessen: der rote Faden */
export function RedThread() {
  const root = useRef<HTMLDivElement>(null);
  const [i, setI] = useState(0);
  const objs = interestsThread.objects;

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const t = setInterval(() => setI((v) => (v + 1) % objs.length), 1700);
    return () => clearInterval(t);
  }, [objs.length]);

  useGSAP(
    () => {
      gsap.matchMedia().add(MQ.motion, () => {
        gsap.fromTo(`.${s.rtLine}`, { strokeDashoffset: 1 }, { strokeDashoffset: 0, duration: 2, ease: "power2.inOut", stagger: 0.15, scrollTrigger: { trigger: root.current, start: "top 70%", once: true } });
      });
    },
    { scope: root },
  );

  return (
    <div ref={root} className={s.redThread}>
      <p className={`${s.rtLead} serif`}>{interestsThread.lead}</p>
      <p className={`${s.rtCore} display`}>
        Ich möchte Dinge gestalten
        <br />
        und ihnen meinen eigenen Stil geben.
      </p>
      <p className={s.rtRotate} aria-hidden="true">
        Das kann{" "}
        <span className={s.rtWord}>
          <span key={i}>{objs[i]}</span>
        </span>{" "}
        sein.
      </p>
      <p className="sr-only">Das kann {objs.join(", ")} sein.</p>
      <svg viewBox="0 0 800 120" className={s.rtSvg} aria-hidden="true">
        {objs.map((_, k) => {
          const x = 100 + k * 200;
          return <path key={k} className={s.rtLine} pathLength={1} d={`M${x},20 C ${x},80 400,60 400,110`} />;
        })}
        <circle cx={400} cy={110} r={7} className={s.rtDot} />
      </svg>
      <ul className={s.rtLinks}>
        {objs.map((o, k) => (
          <li key={o} data-on={k === i}>
            <a href={TARGETS[k]}>{o}</a>
          </li>
        ))}
      </ul>
    </div>
  );
}
