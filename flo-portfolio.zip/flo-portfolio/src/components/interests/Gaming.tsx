"use client";
import { useRef } from "react";
import { gaming } from "@/data/interests";
import { gsap, useGSAP, MQ } from "@/lib/gsap";
import s from "./Interests.module.css";

/** Gaming: vom Bildschirm hinter die Kulissen – eine zweite Ebene schiebt sich beim Scrollen darüber */
export function Gaming() {
  const root = useRef<HTMLDivElement>(null);
  useGSAP(
    () => {
      gsap.matchMedia().add(MQ.motion, () => {
        gsap.fromTo(`.${s.gmBack}`, { clipPath: "inset(0 0 0 100%)" }, {
          clipPath: "inset(0 0 0 0%)",
          ease: "none",
          scrollTrigger: { trigger: `.${s.gmStage}`, start: "top 60%", end: "bottom 40%", scrub: 0.6 },
        });
      });
    },
    { scope: root },
  );
  return (
    <div ref={root} className={s.gaming} id="i-gaming">
      <div className={s.gmStage}>
        <div className={s.gmFront}>
          <span className="meta">Früher · vor dem Bildschirm</span>
          <ul>
            {gaming.games.map((g) => (
              <li key={g} className="display">
                {g}
              </li>
            ))}
          </ul>
        </div>
        <div className={s.gmBack}>
          <span className="meta">Heute · dahinter</span>
          <p className="display">{gaming.headline}</p>
          <span className={s.gmSub}>Medien & Video für Gaming-Vereine, z. B. GlazeX e.V.</span>
        </div>
      </div>
      <div className={s.gmText}>
        {gaming.text.map((t, i) => (
          <p key={i}>{t}</p>
        ))}
        <p className={`${s.gmCloser} serif`}>{gaming.closer}</p>
        <a className="xref" href="#mein-umfeld">
          Lasse & der Freundeskreis
        </a>
      </div>
    </div>
  );
}
