"use client";
import { useRef } from "react";
import { voice } from "@/data/interests";
import { gsap, useGSAP, MQ } from "@/lib/gsap";
import s from "./Interests.module.css";

const BARS = 72;
// ruhige, feste Grundform – keine Dauerbewegung
const base = Array.from({ length: BARS }, (_, i) => 0.18 + 0.55 * Math.abs(Math.sin(i * 0.37) * Math.cos(i * 0.11)));

/** Musik & Synchronsprechen – eine Wellenform, die auf den Cursor / Fingertipp reagiert */
export function Voice() {
  const root = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      gsap.matchMedia().add(MQ.motion, () => {
        const bars = gsap.utils.toArray<HTMLElement>(`.${s.bar}`, root.current);
        gsap.fromTo(bars, { scaleY: 0.02 }, { scaleY: (i) => base[i], stagger: { each: 0.01, from: "center" }, duration: 1, scrollTrigger: { trigger: `.${s.wave}`, start: "top 85%", once: true } });
        const wave = root.current!.querySelector<HTMLElement>(`.${s.wave}`)!;
        const react = (clientX: number) => {
          const r = wave.getBoundingClientRect();
          const x = (clientX - r.left) / r.width;
          bars.forEach((b, i) => {
            const d = Math.abs(i / BARS - x);
            const boost = Math.max(0, 1 - d * 7);
            gsap.to(b, { scaleY: Math.min(1, base[i] + boost * 0.7), duration: 0.35, ease: "power2.out", overwrite: true });
          });
        };
        const reset = () => bars.forEach((b, i) => gsap.to(b, { scaleY: base[i], duration: 0.8, ease: "power3.out", overwrite: true }));
        const move = (e: PointerEvent) => react(e.clientX);
        const tap = (e: PointerEvent) => {
          react(e.clientX);
          setTimeout(reset, 500);
        };
        wave.addEventListener("pointermove", move);
        wave.addEventListener("pointerleave", reset);
        wave.addEventListener("pointerdown", tap);
        return () => {
          wave.removeEventListener("pointermove", move);
          wave.removeEventListener("pointerleave", reset);
          wave.removeEventListener("pointerdown", tap);
        };
      });
    },
    { scope: root },
  );

  return (
    <div ref={root} className={s.voice} id="i-musik">
      <div className={s.wave} aria-hidden="true" data-cursor="STIMME">
        {base.map((h, i) => (
          <span key={i} className={s.bar} style={{ transform: `scaleY(${h})` }} />
        ))}
      </div>
      <div className={s.voiceGrid}>
        <div>
          <span className="meta signal">Musik</span>
          <h3 className={`${s.midHead} display`}>Worte.</h3>
          <p>{voice.music}</p>
          <ul className={s.pills}>
            {voice.musicPoints.map((p) => (
              <li key={p}>{p}</li>
            ))}
          </ul>
        </div>
        <div>
          <span className="meta signal">Synchronsprechen · seit 2026</span>
          <h3 className={`${s.midHead} display`}>Stimme.</h3>
          <p>{voice.dub}</p>
          <ul className={s.pills}>
            {voice.dubPoints.map((p) => (
              <li key={p}>{p}</li>
            ))}
          </ul>
          <p className={`${s.note} meta`}>{voice.dubNote}</p>
        </div>
      </div>
    </div>
  );
}
