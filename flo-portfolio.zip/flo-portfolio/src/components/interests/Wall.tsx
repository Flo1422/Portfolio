"use client";
import { useRef } from "react";
import { graffiti } from "@/data/interests";
import { Img } from "@/components/core/Img";
import { MaskText } from "@/components/core/MaskText";
import { gsap, useGSAP, MQ } from "@/lib/gsap";
import s from "./Interests.module.css";

/** Graffiti: Haltung + horizontale digitale Wandgalerie */
export function Wall() {
  const root = useRef<HTMLDivElement>(null);
  useGSAP(
    () => {
      gsap.matchMedia().add({ motion: MQ.motion, desktop: MQ.desktop }, (ctx) => {
        const { motion, desktop } = ctx.conditions as Record<string, boolean>;
        if (!motion) return;
        // Phasen-Linie
        gsap.fromTo(`.${s.phaseLine}`, { scaleX: 0 }, { scaleX: 1, ease: "none", scrollTrigger: { trigger: `.${s.phases}`, start: "top 85%", end: "top 45%", scrub: true } });
        gsap.fromTo(`.${s.phase}`, { opacity: 0.15 }, { opacity: 1, stagger: 0.25, ease: "none", scrollTrigger: { trigger: `.${s.phases}`, start: "top 85%", end: "top 45%", scrub: true } });
        if (!desktop) return;
        const wall = root.current!.querySelector<HTMLElement>(`.${s.wall}`)!;
        const track = wall.querySelector<HTMLElement>(`.${s.wallTrack}`)!;
        wall.classList.add(s.wallDriven);
        const dist = () => track.scrollWidth - window.innerWidth;
        gsap.to(track, {
          x: () => -dist(),
          ease: "none",
          scrollTrigger: { trigger: wall, start: "top top", end: () => `+=${dist()}`, pin: true, scrub: 0.6, invalidateOnRefresh: true, anticipatePin: 1 },
        });
        gsap.utils.toArray<HTMLElement>(`.${s.piece}`).forEach((p, i) => {
          gsap.fromTo(p, { rotate: i % 2 ? 4 : -4 }, { rotate: i % 2 ? -1.5 : 1.5, ease: "none", scrollTrigger: { trigger: wall, start: "top top", end: () => `+=${dist()}`, scrub: true } });
        });
        return () => wall.classList.remove(s.wallDriven);
      });
    },
    { scope: root },
  );

  return (
    <div ref={root} className={s.graffiti} id="i-graffiti">
      <div className="wrap">
      <div className={s.gIntro}>
        <span className="meta signal">Graffiti</span>
        <MaskText lines={["Alles kann eine", "Leinwand sein."]} className={`${s.bigHead} display`} />
      </div>
      <div className={s.gGrid}>
        <div className={s.gMeaning}>
          {graffiti.meaning.map((m, i) => (
            <p key={i} className={i === 0 ? `${s.gLead} serif` : ""}>
              {m}
            </p>
          ))}
        </div>
        <dl className={s.gFacts}>
          {graffiti.facts.map((f) => (
            <div key={f.k}>
              <dt className="meta">{f.k}</dt>
              <dd>{f.v}</dd>
            </div>
          ))}
        </dl>
      </div>

      <div className={s.phases}>
        <span className={s.phaseLine} aria-hidden="true" />
        <ol>
          {graffiti.phases.map((p) => (
            <li key={p.year} className={s.phase}>
              <span className={`${s.phaseYear} display`}>{p.year}</span>
              <span className={s.phaseLabel}>{p.label}</span>
            </li>
          ))}
        </ol>
        <p className={s.today}>{graffiti.today}</p>
      </div>
      </div>

      <div className={s.wall} aria-label="Wandgalerie: meine Arbeiten" tabIndex={0} role="region">
        <div className={s.wallTrack}>
          <div className={s.wallTitle}>
            <span className="meta">Wandgalerie</span>
            <p className="display">Meine Wand.</p>
            <span className={`${s.wallHint} meta`}>→ scrollen oder wischen</span>
          </div>
          {graffiti.wall.map((w, i) => (
            <figure key={i} className={s.piece} data-cursor="ANSEHEN">
              <Img slot={w.photo} className={s.pieceImg} style={{ aspectRatio: w.ratio }} />
              {w.caption && <figcaption className="meta">{w.caption}</figcaption>}
            </figure>
          ))}
        </div>
      </div>
    </div>
  );
}
