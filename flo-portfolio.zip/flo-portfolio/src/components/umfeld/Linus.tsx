"use client";
import { useRef } from "react";
import { gsap, useGSAP, MQ } from "@/lib/gsap";
import s from "./Umfeld.module.css";

/** Linus: FSJ → gleiche Schule, andere Stufe → Sommer 2026 gleiche Klasse */
export function Linus() {
  const root = useRef<HTMLDivElement>(null);
  useGSAP(
    () => {
      gsap.matchMedia().add(MQ.motion, () => {
        gsap.fromTo(`.${s.lnPath}`, { strokeDashoffset: 1 }, {
          strokeDashoffset: 0,
          ease: "none",
          scrollTrigger: { trigger: root.current, start: "top 80%", end: "bottom 60%", scrub: 0.6 },
        });
      });
    },
    { scope: root },
  );
  return (
    <div ref={root} className={s.linus}>
      <div>
        <span className="meta">Berufsschule</span>
        <h3 className="display">Zwei Wege, eine Klasse.</h3>
        <p>
          Emil, Paul und Jason habe ich durch die Berufsschule kennengelernt. Linus kenne ich aus dem FSJ. Dort haben wir zusammen mit Felix auch zusammengearbeitet, und bis heute ist er Arbeitskollege von Anthony und Felix. Danach waren wir an derselben Berufsschule, er zunächst eine Stufe über uns. Seit Sommer 2026 ist er in meiner Klasse.
        </p>
      </div>
      <svg viewBox="0 0 800 220" className={s.lnSvg} role="img" aria-label="FSJ 2023/24, dann 2024 bis 2026 gleiche Berufsschule in unterschiedlichen Stufen, ab Sommer 2026 gleiche Klasse">
        <path className={s.lnPath} pathLength={1} d="M40 110 C 120 110, 140 50, 220 50 L 600 50 C 680 50, 700 110, 760 110" />
        <path className={`${s.lnPath} ${s.lnMe}`} pathLength={1} d="M40 110 C 120 110, 140 170, 220 170 L 600 170 C 680 170, 700 110, 760 110" />
        <circle cx={40} cy={110} r={7} className={s.lnNode} />
        <circle cx={760} cy={110} r={9} className={s.lnEnd} />
        <text x={40} y={145} textAnchor="middle">FSJ 2023/24</text>
        <text x={410} y={36} textAnchor="middle">Linus · eine Stufe weiter</text>
        <text x={410} y={200} textAnchor="middle">Flo · Emil · Paul · Jason</text>
        <text x={760} y={148} textAnchor="middle">Sommer 2026</text>
        <text x={760} y={166} textAnchor="middle">gleiche Klasse</text>
      </svg>
    </div>
  );
}
