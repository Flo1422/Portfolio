"use client";
import { useRef } from "react";
import { gsap, useGSAP, MQ } from "@/lib/gsap";
import s from "./Umfeld.module.css";

const CHAIN = [
  { label: "Felix", note: "Kindheitsfreund" },
  { label: "Theater", note: "Ratz-Fatz" },
  { label: "Anthony", note: "ca. ein Jahr vor dem FSJ", key: true },
  { label: "FSJ", note: "gleiche Einrichtung" },
  { label: "Graffiti", note: "zurück, jetzt legal" },
  { label: "Freunde", note: "half bei der Integration" },
  { label: "Arbeit", note: "Empfehlung für meine Kita" },
  { label: "Motorrad", note: "zusammen gefahren · 690 SMC R gekauft · Ole, Leo, Alex & Sasha" },
];

/** Anthony als Verbindungspunkt – eine Kette, die sich beim Scrollen schließt */
export function Chain() {
  const root = useRef<HTMLDivElement>(null);
  useGSAP(
    () => {
      gsap.matchMedia().add(MQ.motion, () => {
        const tl = gsap.timeline({ scrollTrigger: { trigger: root.current, start: "top 75%", end: "bottom 55%", scrub: 0.6 } });
        tl.fromTo(`.${s.chainLine}`, { scale: 0 }, { scale: 1, ease: "none", duration: CHAIN.length });
        gsap.utils.toArray<HTMLElement>(`.${s.chainItem}`, root.current).forEach((it, i) => {
          tl.fromTo(it, { opacity: 0.15, y: 10 }, { opacity: 1, y: 0, duration: 0.6 }, i);
        });
      });
    },
    { scope: root },
  );
  return (
    <div ref={root} className={s.chain}>
      <div className={s.chainHead}>
        <span className="meta">Ein wichtiger Verbindungspunkt</span>
        <h3 className="display">Anthony.</h3>
        <p>
          Ich kannte Anthony bereits ungefähr ein Jahr vor meinem FSJ über Felix und unsere Theatergruppe. Danach waren wir in derselben FSJ-Einrichtung. Anthony brachte mich nach meiner Pause wieder zum Graffiti zurück, jetzt auf legalem Weg. Nach meinem FSJ empfahl er mir die Kita, in der ich heute arbeite. Und auch beim Motorrad hängt vieles an ihm: Wir sind zusammen gefahren, ich habe ihm seine KTM 690 SMC R abgekauft, und über ihn kenne ich weitere Leute aus dem Motorradkreis.
        </p>
      </div>
      <div className={s.chainTrack}>
        <span className={s.chainLine} aria-hidden="true" />
        <ol>
          {CHAIN.map((c) => (
            <li key={c.label} className={s.chainItem} data-key={c.key}>
              <span className={s.chainDot} aria-hidden="true" />
              <span className={`${s.chainLabel} display`}>{c.label}</span>
              <span className={`${s.chainNote} meta`}>{c.note}</span>
            </li>
          ))}
        </ol>
      </div>
    </div>
  );
}
