"use client";
import { useMemo, useRef, useState, useEffect } from "react";
import { areas, stories } from "@/data/people";
import { buildGraph, neighborhood, subset, W, H, type GNode } from "@/lib/graph";
import { gsap, useGSAP, MQ } from "@/lib/gsap";
import { PersonDetail } from "./PersonDetail";
import { personById, areaById, membersOf } from "./shared";
import s from "./Umfeld.module.css";

type Focus = { type: "person" | "area" | "story"; id: string } | null;

/**
 * Räumliche Verbindungskarte (Desktop).
 * Hover = Vorschau · Klick = festhalten · Esc = zurücksetzen.
 */
export function Network() {
  const { nodes, links } = useMemo(() => buildGraph(), []);
  const nodeById = useMemo(() => Object.fromEntries(nodes.map((n) => [n.id, n])), [nodes]);
  const root = useRef<HTMLDivElement>(null);
  const [hover, setHover] = useState<Focus>(null);
  const [pinned, setPinned] = useState<Focus>(null);
  const focus = hover ?? pinned;

  const active = useMemo(() => {
    if (!focus) return null;
    if (focus.type === "story") {
      const st = stories.find((x) => x.id === focus.id)!;
      return subset(st.highlight, links);
    }
    const n = neighborhood([focus.id], links);
    // Verbindung der beteiligten Bereiche zurück zu Flo sichtbar machen
    links.forEach((l) => {
      if (l.kind === "me" && n.nodes.has(l.target)) {
        n.links.add(l.id);
        n.nodes.add("flo");
      }
    });
    return n;
  }, [focus, links]);

  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === "Escape" && setPinned(null);
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, []);

  useGSAP(
    () => {
      gsap.matchMedia().add({ motion: MQ.motion, fine: MQ.fine }, (ctx) => {
        const { motion, fine } = ctx.conditions as Record<string, boolean>;
        if (!motion) return;
        const tl = gsap.timeline({ scrollTrigger: { trigger: root.current, start: "top 70%", once: true } });
        tl.fromTo(`.${s.floDot}`, { attr: { r: 0 } }, { attr: { r: 16 }, duration: 0.8, ease: "back.out(2)" })
          .fromTo(`.${s.gLink}`, { strokeDashoffset: 1 }, { strokeDashoffset: 0, duration: 1.6, stagger: 0.004, ease: "power2.out" }, 0.2)
          .fromTo(`.${s.gArea}`, { opacity: 0 }, { opacity: 1, stagger: 0.06, duration: 0.8, clearProps: "opacity" }, 0.3)
          .fromTo(`.${s.gPerson}`, { opacity: 0 }, { opacity: 1, duration: 0.8, stagger: { each: 0.012, from: "center" }, clearProps: "opacity" }, 0.7);

        if (!fine) return;
        // leichte Tiefenwirkung: Ebenen verschieben sich unterschiedlich
        const layers = [
          { el: root.current!.querySelector(`.${s.gLayerPeople}`), d: 10 },
          { el: root.current!.querySelector(`.${s.gLayerAreas}`), d: 5 },
        ];
        const setters = layers.map((l) => ({
          x: gsap.quickTo(l.el, "x", { duration: 1.2, ease: "power3" }),
          y: gsap.quickTo(l.el, "y", { duration: 1.2, ease: "power3" }),
          d: l.d,
        }));
        const move = (e: PointerEvent) => {
          const r = root.current!.getBoundingClientRect();
          const nx = (e.clientX - r.left) / r.width - 0.5;
          const ny = (e.clientY - r.top) / r.height - 0.5;
          setters.forEach((st) => {
            st.x(nx * st.d);
            st.y(ny * st.d);
          });
        };
        root.current!.addEventListener("pointermove", move);
        return () => root.current?.removeEventListener("pointermove", move);
      });
    },
    { scope: root },
  );

  const state = (id: string) => (!active ? "" : active.nodes.has(id) ? (focus?.id === id ? "focus" : "on") : "off");
  const lstate = (id: string) => (!active ? "" : active.links.has(id) ? "on" : "off");

  const select = (f: Focus) => setPinned((p) => (p && f && p.id === f.id ? null : f));

  const nodeProps = (n: GNode, f: Focus) => ({
    tabIndex: 0,
    role: "button" as const,
    "aria-pressed": pinned?.id === n.id,
    "aria-label": n.kind === "person" ? `${n.label}: ${personById[n.id].role}` : `Bereich ${n.label}`,
    onMouseEnter: () => setHover(f),
    onMouseLeave: () => setHover(null),
    onFocus: () => setHover(f),
    onBlur: () => setHover(null),
    onClick: () => select(f),
    onKeyDown: (e: React.KeyboardEvent) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        select(f);
      }
    },
    "data-cursor": "ANSEHEN",
  });

  // Panel-Inhalt
  const panel = (() => {
    const f = focus;
    if (!f)
      return (
        <div className={s.detail}>
          <span className="meta">So funktioniert’s</span>
          <p className={s.panelIntro}>
            Fahre über einen Namen oder Bereich oder klicke, um ihn festzuhalten. Die Verbindungen treten hervor, alles andere tritt zurück.
          </p>
          <span className="meta">Bereiche</span>
          <ul className={s.detailChips}>
            {areas.map((a) => (
              <li key={a.id}>
                <button onClick={() => select({ type: "area", id: a.id })} style={{ "--c": a.color } as React.CSSProperties}>
                  {a.label} <span className={s.relLabel}>{membersOf(a.id).length}</span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      );
    if (f.type === "person")
      return (
        <PersonDetail
          person={personById[f.id]}
          onArea={(id) => setPinned({ type: "area", id })}
          onPerson={(id) => setPinned({ type: "person", id })}
        />
      );
    if (f.type === "area") {
      const a = areaById[f.id];
      return (
        <div className={s.detail}>
          <span className="meta">Bereich</span>
          <h4 className={`${s.detailName} display`} style={{ color: a.color }}>
            {a.label}
          </h4>
          <p className={s.detailRole}>{a.note}</p>
          <ul className={s.detailChips}>
            {membersOf(a.id).map((p) => (
              <li key={p.id}>
                <button onClick={() => setPinned({ type: "person", id: p.id })}>{p.name}</button>
              </li>
            ))}
          </ul>
        </div>
      );
    }
    const st = stories.find((x) => x.id === f.id)!;
    return (
      <div className={s.detail}>
        <span className="meta">Geschichte</span>
        <h4 className={`${s.detailName} display`}>{st.title}</h4>
        <ol className={s.detailPath}>
          {st.steps.map((x, i) => (
            <li key={i}>{x}</li>
          ))}
        </ol>
        {st.text && <p className={s.detailRole}>{st.text}</p>}
      </div>
    );
  })();

  return (
    <div className={s.network} ref={root} data-focus={!!active}>
      <div className={s.graphWrap}>
        <svg viewBox={`0 0 ${W} ${H}`} className={s.graph} role="group" aria-label="Verbindungskarte: Flo, Lebensbereiche und Menschen">
          <g className={s.gLinks}>
            {links.map((l) => {
              const a = nodeById[l.source];
              const b = nodeById[l.target];
              // leicht gebogene Linien
              const mx = (a.x! + b.x!) / 2 + (b.y! - a.y!) * 0.08;
              const my = (a.y! + b.y!) / 2 - (b.x! - a.x!) * 0.08;
              const color = l.kind === "member" ? nodeById[l.target].color : undefined;
              return (
                <path
                  key={l.id}
                  className={s.gLink}
                  data-kind={l.kind}
                  data-state={lstate(l.id)}
                  d={`M${a.x},${a.y} Q${mx},${my} ${b.x},${b.y}`}
                  pathLength={1}
                  style={{ "--c": color } as React.CSSProperties}
                />
              );
            })}
          </g>
          <g className={s.gLayerPeople}>
            {nodes
              .filter((n) => n.kind === "person")
              .map((n) => (
                <g
                  key={n.id}
                  className={s.gPerson}
                  data-state={state(n.id)}
                  data-key={n.key}
                  transform={`translate(${n.x},${n.y})`}
                  {...nodeProps(n, { type: "person", id: n.id })}
                >
                  <circle r={14} className={s.hit} />
                  <circle r={n.r} className={s.dot} />
                  <text y={n.r + 13} textAnchor="middle">
                    {n.label}
                  </text>
                </g>
              ))}
          </g>
          <g className={s.gLayerAreas}>
            {nodes
              .filter((n) => n.kind === "area")
              .map((n) => (
                <g
                  key={n.id}
                  className={s.gArea}
                  data-state={state(n.id)}
                  transform={`translate(${n.x},${n.y})`}
                  style={{ "--c": n.color } as React.CSSProperties}
                  {...nodeProps(n, { type: "area", id: n.id })}
                >
                  <circle r={22} className={s.hit} />
                  <circle r={n.r} className={s.dot} />
                  <circle r={n.r + 6} className={s.ring} />
                  <text y={-18} textAnchor="middle">
                    {n.label}
                  </text>
                </g>
              ))}
          </g>
          <g className={s.gFlo} transform={`translate(${W / 2},${H / 2})`} data-state={state("flo")}>
            <circle r={34} className={s.floHalo} />
            <circle r={16} className={s.floDot} />
            <text y={5} textAnchor="middle">
              FLO
            </text>
          </g>
        </svg>
      </div>

      <aside className={s.panel} aria-live="polite">
        {panel}
        {pinned && (
          <button className={s.reset} onClick={() => setPinned(null)}>
            Auswahl aufheben
          </button>
        )}
      </aside>

      <div className={s.storyBar}>
        <span className="meta">Geschichten</span>
        <ul>
          {stories.map((st) => (
            <li key={st.id}>
              <button
                aria-pressed={pinned?.id === st.id}
                onClick={() => select({ type: "story", id: st.id })}
                onMouseEnter={() => setHover({ type: "story", id: st.id })}
                onMouseLeave={() => setHover(null)}
              >
                {st.title}
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
