import { areas, people, relations, type Person } from "@/data/people";

export const personById: Record<string, Person> = Object.fromEntries(people.map((p) => [p.id, p]));
export const areaById = Object.fromEntries(areas.map((a) => [a.id, a]));

export function relationsOf(id: string) {
  return relations
    .filter((r) => r.from === id || r.to === id)
    .map((r) => ({ other: personById[r.from === id ? r.to : r.from], label: r.label }))
    .filter((r) => r.other);
}

export function membersOf(areaId: string) {
  return people.filter((p) => p.areas.includes(areaId as Person["areas"][number]));
}
