"use client";
import type { Person } from "@/data/people";
import { areaById, relationsOf } from "./shared";
import s from "./Umfeld.module.css";

/** Detailkarte einer Person – auf Desktop im Panel, mobil im Bottom-Sheet */
export function PersonDetail({
  person,
  onArea,
  onPerson,
}: {
  person: Person;
  onArea?: (id: string) => void;
  onPerson?: (id: string) => void;
}) {
  const rel = relationsOf(person.id);
  return (
    <div className={s.detail}>
      <span className="meta">{person.since ? `seit ${person.since}` : "Mein Umfeld"}</span>
      <h4 className={`${s.detailName} display`}>{person.name}</h4>
      <p className={s.detailRole}>{person.role}</p>

      {person.path && person.path.length > 0 && (
        <ol className={s.detailPath} aria-label="Wie wir verbunden sind">
          {person.path.map((p, i) => (
            <li key={i}>{p}</li>
          ))}
        </ol>
      )}

      <div className={s.detailGroup}>
        <span className="meta">Bereiche</span>
        <ul className={s.detailChips}>
          {person.areas.map((a) => (
            <li key={a}>
              <button onClick={() => onArea?.(a)} style={{ "--c": areaById[a].color } as React.CSSProperties}>
                {areaById[a].label}
              </button>
            </li>
          ))}
        </ul>
      </div>

      {rel.length > 0 && (
        <div className={s.detailGroup}>
          <span className="meta">Verbunden mit</span>
          <ul className={s.detailChips}>
            {rel.map((r) => (
              <li key={r.other.id}>
                <button onClick={() => onPerson?.(r.other.id)}>
                  {r.other.name} <span className={s.relLabel}>· {r.label}</span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
