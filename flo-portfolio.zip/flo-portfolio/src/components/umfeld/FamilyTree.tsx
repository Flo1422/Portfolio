"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { family, familyHeadline } from "@/data/family";
import { gsap, useGSAP, MQ } from "@/lib/gsap";
import s from "./Family.module.css";

const kern = family.find((b) => b.id === "fam-kern")!;
const others = family.filter((b) => b.id !== "fam-kern");

function Member({ pid, name, role, isMe }: { pid: string; name: string; role: string; isMe?: boolean }) {
  return (
    <li className={s.member} data-pid={pid} data-me={isMe}>
      <span className={`${s.mName} display`}>{name}</span>
      <span className={s.mRole}>{role}</span>
    </li>
  );
}

function Branch({ id, area, hot, setHot }: { id: string; area: string; hot: string | null; setHot: (v: string | null) => void }) {
    const b = family.find((x) => x.id === id)!;
    const gen0 = b.members.filter((m) => m.generation === 0);
    const gen1 = b.members.filter((m) => m.generation === 1 && !m.pet);
    const pets = b.members.filter((m) => m.pet);
    const attachText = b.attachTo === "p-olaf" ? "über Papa" : b.attachTo === "p-simone" ? "über Mama" : b.attachTo === "flo" ? "mit mir verbunden" : "";
    return (
      <div
        className={s.branch}
        data-branch={b.id}
        data-hot={hot === b.id}
        style={{ gridArea: area }}
        onMouseEnter={() => setHot(b.id)}
        onMouseLeave={() => setHot(null)}
      >
        <div className={s.bHead}>
          <span className="meta">{b.label}</span>
          {attachText && <span className={`${s.attach} meta`}>{attachText}</span>}
        </div>
        <ul className={s.gen}>
          {gen0.map((m) => (
            <Member key={m.personId} pid={m.personId} name={m.name} role={m.role} isMe={m.isMe} />
          ))}
        </ul>
        {gen1.length > 0 && (
          <ul className={`${s.gen} ${s.gen1}`}>
            {gen1.map((m) => (
              <Member key={m.personId} pid={m.personId} name={m.name} role={m.role} isMe={m.isMe} />
            ))}
          </ul>
        )}
        {pets.length > 0 && (
          <ul className={s.pets} aria-label="Haustiere">
            {pets.map((m) => (
              <li key={m.personId} className={s.pet} data-pid={m.personId}>
                <svg className={s.petMark} viewBox="0 0 24 24" aria-hidden="true">
                  <ellipse cx="12" cy="16" rx="5" ry="4.2" />
                  <circle cx="5.5" cy="10" r="2.2" />
                  <circle cx="9.5" cy="6" r="2.2" />
                  <circle cx="14.5" cy="6" r="2.2" />
                  <circle cx="18.5" cy="10" r="2.2" />
                </svg>
                <span className={`${s.mName} display`}>{m.name}</span>
                <span className={s.mRole}>{m.role}</span>
              </li>
            ))}
          </ul>
        )}
        {b.note && <p className={`${s.bNote} serif`}>{b.note}</p>}
      </div>
    );
  }

/**
 * Familienbaum – bewusst kein biologisch vollständiger Stammbaum.
 * Desktop: Raster mit gezeichneten Verbindungen (werden aus den echten Positionen berechnet).
 * Mobile: gestapelte Zweige mit Verbindungslinie.
 */
export function FamilyTree() {
  const root = useRef<HTMLDivElement>(null);
  const [paths, setPaths] = useState<{ id: string; d: string; branch: string; kind: string }[]>([]);
  const [hot, setHot] = useState<string | null>(null);


  const measure = useCallback(() => {
    const el = root.current;
    if (!el) return;
    const box = el.getBoundingClientRect();
    const pt = (sel: string) => {
      const n = el.querySelector<HTMLElement>(sel);
      if (!n) return null;
      const r = n.getBoundingClientRect();
      return { l: r.left - box.left, r: r.right - box.left, t: r.top - box.top, b: r.bottom - box.top, cx: r.left - box.left + r.width / 2, cy: r.top - box.top + r.height / 2 };
    };
    const desktop = window.innerWidth >= 900;
    const out: { id: string; d: string; branch: string; kind: string }[] = [];
    // Paare
    family.forEach((b) =>
      b.couples?.forEach(([a, c]) => {
        const p = pt(`[data-pid="${a}"]`);
        const q = pt(`[data-pid="${c}"]`);
        if (p && q && Math.abs(p.cy - q.cy) < 10) out.push({ id: `c-${a}`, d: `M${p.r},${p.cy} L${q.l},${q.cy}`, branch: b.id, kind: "couple" });
      }),
    );
    // Kinder der Kernfamilie
    kern.children?.forEach((ch) => {
      const a = pt(`[data-pid="${ch.parents[0]}"]`);
      const b = pt(`[data-pid="${ch.parents[1]}"]`);
      if (!a || !b) return;
      const mx = (a.r + b.l) / 2;
      const my = a.cy;
      ch.kids.forEach((k) => {
        const kk = pt(`[data-pid="${k}"]`);
        if (!kk) return;
        const midY = (my + kk.t) / 2;
        out.push({ id: `k-${k}`, d: `M${mx},${my} L${mx},${midY} L${kk.cx},${midY} L${kk.cx},${kk.t}`, branch: "fam-kern", kind: "child" });
      });
    });
    // Zweige andocken
    if (desktop) {
      others.forEach((b) => {
        const from = pt(`[data-pid="${b.attachTo}"]`);
        const to = pt(`[data-branch="${b.id}"]`);
        if (!from || !to) return;
        const leftSide = to.cx < from.cx;
        const x1 = leftSide ? from.l : from.r;
        const x2 = leftSide ? to.r : to.l;
        const y2 = to.t + 34;
        const mx = (x1 + x2) / 2;
        out.push({ id: `a-${b.id}`, d: `M${x1},${from.cy} C${mx},${from.cy} ${mx},${y2} ${x2},${y2}`, branch: b.id, kind: "attach" });
      });
    }
    setPaths(out);
  }, []);

  useEffect(() => {
    measure();
    const ro = new ResizeObserver(measure);
    if (root.current) ro.observe(root.current);
    document.fonts?.ready.then(measure);
    return () => ro.disconnect();
  }, [measure]);

  useGSAP(
    () => {
      gsap.matchMedia().add(MQ.motion, () => {
        gsap.fromTo(`.${s.branch}`, { y: 30, opacity: 0 }, {
          y: 0,
          opacity: 1,
          stagger: 0.12,
          duration: 1,
          scrollTrigger: { trigger: root.current, start: "top 70%", once: true, onEnter: () => root.current?.classList.add(s.drawn) },
        });
      });
    },
    { scope: root },
  );

  return (
    <div className={s.family}>
      <h3 className={`${s.headline} display`}>{familyHeadline}</h3>
      <div ref={root} className={s.tree}>
        <svg className={s.svg} aria-hidden="true">
          {paths.map((p) => (
            <path key={p.id} d={p.d} className={s.conn} data-kind={p.kind} data-hot={hot === p.branch} pathLength={1} />
          ))}
        </svg>
        <Branch id="fam-vaeterlich" area="v" hot={hot} setHot={setHot} />
        <Branch id="fam-kern" area="k" hot={hot} setHot={setHot} />
        <Branch id="fam-muetterlich" area="m" hot={hot} setHot={setHot} />
        <Branch id="fam-zieh" area="z" hot={hot} setHot={setHot} />
      </div>
    </div>
  );
}
