"use client";
import { useEffect, useRef, useState } from "react";
import { areas, people, stories, type AreaId } from "@/data/people";
import { gsap } from "@/lib/gsap";
import { PersonDetail } from "./PersonDetail";
import { personById, areaById, relationsOf } from "./shared";
import s from "./Umfeld.module.css";

/** Kleine Karte im Bottom-Sheet: Person in der Mitte, Bereiche & Menschen drumherum */
function MiniMap({ id }: { id: string }) {
  const p = personById[id];
  const rel = relationsOf(id);
  const items = [
    ...p.areas.map((a) => ({ key: a, label: areaById[a].label, color: areaById[a].color, kind: "area" })),
    ...rel.map((r) => ({ key: r.other.id, label: r.other.name, color: "var(--fg-2)", kind: "person" })),
  ];
  const R = 88;
  return (
    <svg viewBox="-150 -120 300 240" className={s.mini} aria-hidden="true">
      <line x1={0} y1={0} x2={0} y2={-120} className={s.miniFlo} />
      <text x={6} y={-106} className={s.miniFloText}>
        FLO
      </text>
      {items.map((it, i) => {
        const a = (i / items.length) * Math.PI * 2 + Math.PI / 6;
        const x = Math.cos(a) * R;
        const y = Math.sin(a) * R * 0.8;
        return (
          <g key={it.key}>
            <line x1={0} y1={0} x2={x} y2={y} stroke={it.color} className={s.miniLine} />
            <circle cx={x} cy={y} r={it.kind === "area" ? 6 : 4} fill={it.color} />
            <text x={x} y={y + (y > 0 ? 18 : -10)} textAnchor="middle">
              {it.label}
            </text>
          </g>
        );
      })}
      <circle r={10} className={s.miniMe} />
    </svg>
  );
}

export function Explorer() {
  const [area, setArea] = useState<AreaId | "alle">("alle");
  const [open, setOpen] = useState<string | null>(null);
  const [story, setStory] = useState<string | null>(null);
  const sheet = useRef<HTMLDivElement>(null);
  const lastFocus = useRef<HTMLElement | null>(null);

  const list = area === "alle" ? people : people.filter((p) => p.areas.includes(area));
  const storyIds = story ? new Set(stories.find((x) => x.id === story)!.highlight) : null;

  useEffect(() => {
    if (!open) return;
    const el = sheet.current;
    if (el && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      gsap.fromTo(el.querySelector(`.${s.sheetPanel}`), { yPercent: 100 }, { yPercent: 0, duration: 0.6, ease: "expo.out" });
    }
    (el?.querySelector(`.${s.sheetClose}`) as HTMLElement | null)?.focus();
    const k = (e: KeyboardEvent) => e.key === "Escape" && close();
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const openPerson = (id: string) => {
    lastFocus.current = document.activeElement as HTMLElement;
    setOpen(id);
  };
  const close = () => {
    setOpen(null);
    lastFocus.current?.focus();
  };

  return (
    <div className={s.explorer}>
      <div className={s.tabs} role="tablist" aria-label="Bereich wählen">
        {[{ id: "alle" as const, label: "Alle", color: "var(--fg)" }, ...areas].map((a) => (
          <button
            key={a.id}
            role="tab"
            aria-selected={area === a.id}
            onClick={() => setArea(a.id)}
            style={{ "--c": a.color } as React.CSSProperties}
          >
            {a.label}
          </button>
        ))}
      </div>

      {area !== "alle" && <p className={`${s.areaNote} serif`}>{areaById[area].note}</p>}

      <ul className={s.cards}>
        {list.map((p) => (
          <li key={p.id} data-dim={storyIds ? !storyIds.has(p.id) : false}>
            <button className={s.personCard} onClick={() => openPerson(p.id)}>
              <span className={s.pcName}>{p.name}</span>
              <span className={s.pcRole}>{p.role}</span>
              <span className={s.pcDots} aria-hidden="true">
                {p.areas.map((a) => (
                  <i key={a} style={{ background: areaById[a].color }} />
                ))}
              </span>
              {p.since && <span className={`${s.pcSince} meta`}>seit {p.since}</span>}
            </button>
          </li>
        ))}
      </ul>

      <div className={s.storySwipe}>
        <span className="meta">Geschichten: antippen, um sie hervorzuheben</span>
        <ul>
          {stories.map((st) => (
            <li key={st.id}>
              <button aria-pressed={story === st.id} onClick={() => setStory((c) => (c === st.id ? null : st.id))}>
                <strong>{st.title}</strong>
                <span>{st.steps.join(" → ")}</span>
              </button>
            </li>
          ))}
        </ul>
      </div>

      {open && (
        <div className={s.sheet} ref={sheet} role="dialog" aria-modal="true" aria-label={personById[open].name}>
          <button className={s.sheetBackdrop} aria-label="Schließen" onClick={close} tabIndex={-1} />
          <div className={s.sheetPanel}>
            <button className={s.sheetClose} onClick={close}>
              Schließen ✕
            </button>
            <MiniMap id={open} />
            <PersonDetail person={personById[open]} onArea={(a) => { setArea(a as AreaId); close(); }} onPerson={(id) => setOpen(id)} />
          </div>
        </div>
      )}
    </div>
  );
}
