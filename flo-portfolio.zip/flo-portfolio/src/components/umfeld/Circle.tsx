"use client";
import { useRef } from "react";
import { stories } from "@/data/people";
import { gsap, useGSAP, MQ } from "@/lib/gsap";
import s from "./Umfeld.module.css";

const story = stories.find((x) => x.id === "s-kreis")!;
const R = 190;
/** Echter Umfang – statt pathLength, damit sich der Strich exakt proportional zum Scroll zeichnet */
const C = 2 * Math.PI * R;

/** „Der Kreis schließt sich“ – Felix: Kita → … → Dozent. Der Kreis zeichnet sich beim Scrollen. */
export function Circle() {
  const root = useRef<HTMLDivElement>(null);
  const n = story.steps.length;

  useGSAP(
    () => {
      gsap.matchMedia().add(MQ.motion, () => {
        const el = root.current!;
        el.classList.add(s.circlePinned);
        const labels = gsap.utils.toArray<SVGGElement>(`.${s.cStep}`, el);
        const tl = gsap.timeline({
          defaults: { ease: "none" },
          scrollTrigger: { trigger: el, start: "top top", end: "bottom bottom", scrub: 0.5 },
        });
        tl.fromTo(`.${s.cArc}`, { attr: { "stroke-dashoffset": C } }, { attr: { "stroke-dashoffset": 0 }, duration: n }, 0);
        labels.forEach((l, i) => tl.fromTo(l, { opacity: 0.12 }, { opacity: 1, duration: 0.3 }, i * (n / n) * 0.98));
        tl.fromTo(`.${s.cBefore}`, { opacity: 1 }, { opacity: 0, duration: 0.4 }, n - 0.3)
          .fromTo(`.${s.cAfter}`, { opacity: 0, scale: 0.9 }, { opacity: 1, scale: 1, duration: 0.5 }, n - 0.1)
          .fromTo(`.${s.cClose}`, { scale: 0 }, { scale: 1, duration: 0.3, transformOrigin: "center" }, n - 0.1)
          .to({}, { duration: 0.6 });
        return () => el.classList.remove(s.circlePinned);
      });
    },
    { scope: root },
  );

  return (
    <div ref={root} className={s.circleWrap}>
      <div className={s.circleStage}>
        <div className={s.circleText}>
          <span className="meta">Felix · seit ca. 2007</span>
          <h3 className="display">
            Der Kreis
            <br />
            schließt sich.
          </h3>
          <p>{story.text}</p>
        </div>
        <svg viewBox="-380 -260 760 520" className={s.circleSvg} role="img" aria-label={`Felix: ${story.steps.join(", ")}`}>
          <circle r={R} className={s.cTrack} />
          {/* Als Pfad statt <circle>, damit pathLength zuverlässig greift und sich der Kreis Stück für Stück zeichnet */}
          <path className={s.cArc} strokeDasharray={C} strokeDashoffset={0} d={`M0,${-R} A${R},${R} 0 1 1 0,${R} A${R},${R} 0 1 1 0,${-R}`} />
          {story.steps.map((st, i) => {
            const a = (i / n) * Math.PI * 2 - Math.PI / 2;
            const x = Math.cos(a) * R;
            const y = Math.sin(a) * R;
            const lx = Math.cos(a) * (R + 34);
            const ly = Math.sin(a) * (R + 34);
            return (
              <g key={st} className={s.cStep}>
                <circle cx={x} cy={y} r={i === 0 ? 8 : 5} className={i === 0 ? s.cStart : s.cNode} />
                <text x={lx} y={ly + 4} textAnchor={Math.abs(lx) < 20 ? "middle" : lx > 0 ? "start" : "end"}>
                  {st}
                </text>
              </g>
            );
          })}
          <circle cx={0} cy={-R} r={14} className={s.cClose} />
          <text className={s.cBefore} textAnchor="middle" y={8}>
            Felix
          </text>
          <text className={s.cAfter} textAnchor="middle" y={8}>
            ↺
          </text>
        </svg>
      </div>
    </div>
  );
}
