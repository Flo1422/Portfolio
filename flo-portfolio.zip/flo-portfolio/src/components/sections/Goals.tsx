"use client";
import { useRef } from "react";
import { goals, goalsHeadline } from "@/data/goals";
import { ChapterHead } from "@/components/core/ChapterHead";
import { MaskText } from "@/components/core/MaskText";
import { gsap, useGSAP, MQ } from "@/lib/gsap";
import s from "./Goals.module.css";

/** Lernziele – bewusst ruhig. Drei Ziele erscheinen nacheinander und laufen in einem Punkt zusammen. */
export function Goals() {
  const root = useRef<HTMLElement>(null);
  useGSAP(
    () => {
      gsap.matchMedia().add(MQ.motion, () => {
        gsap.utils.toArray<HTMLElement>(`.${s.goal}`).forEach((g) => {
          const tl = gsap.timeline({ scrollTrigger: { trigger: g, start: "top 75%", once: true }, defaults: { ease: "power3.out" } });
          tl.fromTo(g.querySelector(`.${s.rule}`), { scaleX: 0 }, { scaleX: 1, duration: 1.4, ease: "expo.inOut" })
            .fromTo(g.querySelector(`.${s.nr}`), { opacity: 0 }, { opacity: 1, duration: 1.2 }, 0.3)
            .fromTo(g.querySelector(`.${s.goalText} > span`), { yPercent: 105 }, { yPercent: 0, duration: 1.2 }, 0.4)
            .fromTo(g.querySelectorAll(`.${s.body} > *`), { opacity: 0 }, { opacity: 1, duration: 1.2, stagger: 0.12 }, 0.7);
        });
        gsap.fromTo(`.${s.converge} path`, { strokeDashoffset: 1 }, {
          strokeDashoffset: 0,
          ease: "none",
          scrollTrigger: { trigger: `.${s.converge}`, start: "top 85%", end: "bottom 60%", scrub: true },
        });
      });
    },
    { scope: root },
  );

  return (
    <section ref={root} id="meine-lernziele" className={`${s.goals} chapter`} aria-labelledby="ziele-title">
      <div className="wrap">
        <ChapterHead nr="06" label="Meine Lernziele" />
        <MaskText id="ziele-title" lines={["Wo ich mich", "weiterentwickeln", "möchte."]} className={`${s.title} display`} />

        <ol className={s.list}>
          {goals.map((g) => (
            <li key={g.id} className={s.goal}>
              <span className={s.rule} aria-hidden="true" />
              <div className={s.left}>
                <span className={`${s.nr} display`}>{g.nr}</span>
                <span className="meta">{g.topic}</span>
              </div>
              <div className={s.right}>
                <h3 className={`${s.goalText} serif`}>
                  <span>{g.goal}</span>
                </h3>
                <div className={s.body}>
                  <p>{g.text}</p>
                  <a className="xref" href={`#${g.origin.to}`}>
                    {g.origin.label}
                  </a>
                </div>
              </div>
            </li>
          ))}
        </ol>

        <svg viewBox="0 0 900 160" className={s.converge} aria-hidden="true">
          <path pathLength={1} d="M150 0 C 150 90, 450 80, 450 150" />
          <path pathLength={1} d="M450 0 L 450 150" />
          <path pathLength={1} d="M750 0 C 750 90, 450 80, 450 150" />
          <circle cx={450} cy={152} r={6} />
        </svg>
      </div>
    </section>
  );
}
