"use client";
import { useRef } from "react";
import { hero } from "@/data/site";
import { gsap, useGSAP, MQ } from "@/lib/gsap";
import s from "./Words.module.css";

/**
 * Typografische Scroll-Sequenz: MENSCHEN. KUNST. BEWEGUNG. …
 * Die Wörter dehnen sich in der Breite (variable Schrift), während sie durchlaufen.
 * Ohne Bewegung: einfache Liste.
 */
export function Words() {
  const root = useRef<HTMLElement>(null);

  useGSAP(
    () => {
      gsap.matchMedia().add(MQ.motion, () => {
        const el = root.current!;
        el.classList.add(s.pinned);
        const words = gsap.utils.toArray<HTMLElement>(`.${s.word}`, el);
        const dots = gsap.utils.toArray<HTMLElement>(`.${s.dot}`, el);
        const tl = gsap.timeline({
          defaults: { ease: "none" },
          scrollTrigger: { trigger: el, start: "top top", end: "bottom bottom", scrub: 0.6 },
        });
        words.forEach((w, i) => {
          const inner = w.querySelector("span > span")!;
          tl.fromTo(inner, { yPercent: 140, fontVariationSettings: "'wdth' 62" }, { yPercent: 0, fontVariationSettings: "'wdth' 100", duration: 1 }, i * 2)
            .to(dots[i], { backgroundColor: "var(--fg)", scale: 1.4, duration: 0.3 }, i * 2 + 0.6)
            .to(inner, { yPercent: -140, fontVariationSettings: "'wdth' 125", duration: 1 }, i * 2 + 1.4);
        });
        const n = words.length * 2;
        tl.to(`.${s.dots}`, { opacity: 0, duration: 0.6 }, n - 0.4)
          .fromTo(`.${s.world} .mask > span`, { yPercent: 140 }, { yPercent: 0, stagger: 0.25, duration: 1.2 }, n - 0.2)
          .to({}, { duration: 1 });
        return () => el.classList.remove(s.pinned);
      });
    },
    { scope: root },
  );

  return (
    <section ref={root} className={s.words} aria-label="Was meine Welt ausmacht">
      <div className={s.stage}>
        <ul className={s.list}>
          {hero.words.map((w) => (
            <li key={w} className={`${s.word} display`}>
              <span className="mask">
                <span>{w}</span>
              </span>
            </li>
          ))}
        </ul>
        <div className={s.dots} aria-hidden="true">
          {hero.words.map((w) => (
            <i key={w} className={s.dot} />
          ))}
        </div>
        <p className={s.world}>
          <span className="mask">
            <span className="serif">{hero.after.split(" ").slice(0, 2).join(" ")}</span>
          </span>
          <span className="mask">
            <span className="display">{hero.after.split(" ").slice(2).join(" ")}</span>
          </span>
        </p>
      </div>
    </section>
  );
}
