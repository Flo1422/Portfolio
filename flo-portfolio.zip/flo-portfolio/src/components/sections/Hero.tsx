"use client";
import { useRef } from "react";
import { hero } from "@/data/site";
import { Img } from "@/components/core/Img";
import { gsap, useGSAP, MQ } from "@/lib/gsap";
import s from "./Hero.module.css";

/** Positionen der Collage (Desktop / Mobile in %), Tiefe steuert Parallax */
const LAYOUT = [
  { x: 6, y: 12, w: 17, r: -4, d: 0.9, mx: 4, my: 8, mw: 40 },
  { x: 72, y: 8, w: 22, r: 3, d: 0.5, mx: 58, my: 6, mw: 38 },
  { x: 78, y: 56, w: 16, r: -2, d: 1, mx: 62, my: 66, mw: 34 },
  { x: 14, y: 60, w: 20, r: 2.5, d: 0.35, mx: 2, my: 70, mw: 42 },
  { x: 44, y: 4, w: 13, r: -1.5, d: 0.25, mx: 36, my: 2, mw: 26 },
  { x: 54, y: 70, w: 15, r: 4, d: 0.7, mx: 40, my: 82, mw: 28 },
  { x: 30, y: 30, w: 11, r: -6, d: 0.15, mx: -99, my: 0, mw: 0 },
  { x: 62, y: 34, w: 10, r: 5, d: 0.6, mx: -99, my: 0, mw: 0 },
];
/** Verbindungen zwischen Bildern – das Leitmotiv, schon ganz am Anfang */
const LINKS: [number, number][] = [
  [0, 4], [4, 1], [1, 2], [2, 5], [5, 3], [3, 0], [0, 6], [6, 7], [7, 2], [4, 7], [6, 3],
];

export function Hero() {
  const root = useRef<HTMLElement>(null);
  const svg = useRef<SVGSVGElement>(null);

  useGSAP(
    () => {
      const el = root.current!;
      const items = gsap.utils.toArray<HTMLElement>(`.${s.item}`, el);
      const cards = gsap.utils.toArray<HTMLElement>(`.${s.card}`, el);
      const lines = gsap.utils.toArray<SVGLineElement>("line", svg.current);

      // Linien an Bildmittelpunkte koppeln
      const updateLines = () => {
        const box = el.getBoundingClientRect();
        const c = cards.map((card) => {
          const r = card.getBoundingClientRect();
          return { x: r.left + r.width / 2 - box.left, y: r.top + r.height / 2 - box.top, vis: r.width > 0 };
        });
        LINKS.forEach(([a, b], i) => {
          const l = lines[i];
          if (!l) return;
          const ok = c[a].vis && c[b].vis;
          l.style.display = ok ? "" : "none";
          l.setAttribute("x1", String(c[a].x));
          l.setAttribute("y1", String(c[a].y));
          l.setAttribute("x2", String(c[b].x));
          l.setAttribute("y2", String(c[b].y));
        });
      };
      updateLines();

      const mm = gsap.matchMedia();
      mm.add({ motion: MQ.motion, fine: MQ.fine }, (ctx) => {
        const { motion, fine } = ctx.conditions as { motion: boolean; fine: boolean };
        if (!motion) {
          updateLines();
          return;
        }

        // ── Intro ─────────────────────────────
        const tl = gsap.timeline({ delay: 0.35 });
        const hidden = { y: 0, yPercent: 140 };
        tl.fromTo(`.${s.name} .mask > span`, hidden, { yPercent: 0, duration: 1.6, stagger: 0.06, ease: "expo.out" })
          .fromTo(`.${s.sub} .mask > span`, hidden, { yPercent: 0, duration: 1, stagger: 0.08 }, "-=1.1")
          .fromTo(
            cards,
            { opacity: 0, scale: 0.7, clipPath: "inset(50% 50% 50% 50%)" },
            { opacity: 1, scale: 1, clipPath: "inset(0% 0% 0% 0%)", duration: 1.5, stagger: { each: 0.08, from: "random" } },
            "-=0.9",
          )
          .fromTo(lines, { opacity: 0 }, { opacity: 1, duration: 1.2, stagger: 0.04, ease: "power2.out" }, "-=1")
          .fromTo(`.${s.claim} .mask > span`, hidden, { yPercent: 0, duration: 1.2 }, "-=1.2")
          .fromTo(`.${s.cue}`, { opacity: 0, y: 10 }, { opacity: 1, y: 0, duration: 0.8 }, "-=0.6");

        // ── Scroll: Collage öffnet sich, Name tritt zurück ─────
        items.forEach((it, i) => {
          const d = LAYOUT[i].d;
          const drift = it.firstElementChild as HTMLElement;
          const dirX = LAYOUT[i].x + LAYOUT[i].w / 2 < 50 ? -1 : 1;
          gsap.to(drift, {
            yPercent: -60 * d - 20,
            xPercent: dirX * 30 * d,
            scale: 1 + d * 0.25,
            ease: "none",
            scrollTrigger: { trigger: el, start: "top top", end: "bottom top", scrub: true },
          });
        });
        gsap.to(`.${s.center}`, {
          yPercent: 40,
          scale: 0.86,
          opacity: 0,
          ease: "none",
          scrollTrigger: { trigger: el, start: "top top", end: "bottom top", scrub: true },
        });

        // ── Cursor-Parallax (Desktop) ────────────
        let tx = 0, ty = 0, cx = 0, cy = 0;
        const onMove = (e: PointerEvent) => {
          tx = (e.clientX / window.innerWidth - 0.5) * 2;
          ty = (e.clientY / window.innerHeight - 0.5) * 2;
        };
        if (fine) window.addEventListener("pointermove", onMove, { passive: true });

        let visible = true;
        const io = new IntersectionObserver(([e]) => (visible = e.isIntersecting));
        io.observe(el);
        const tick = () => {
          if (!visible) return;
          cx += (tx - cx) * 0.06;
          cy += (ty - cy) * 0.06;
          items.forEach((it, i) => {
            const d = LAYOUT[i].d;
            it.style.transform = `translate3d(${cx * d * -38}px, ${cy * d * -28}px, 0)`;
          });
          updateLines();
        };
        gsap.ticker.add(tick);
        return () => {
          gsap.ticker.remove(tick);
          window.removeEventListener("pointermove", onMove);
          io.disconnect();
        };
      });

      const onResize = () => updateLines();
      window.addEventListener("resize", onResize);
      return () => window.removeEventListener("resize", onResize);
    },
    { scope: root },
  );

  return (
    <section ref={root} className={s.hero} aria-label="Einstieg">
      <div className={s.collage} aria-hidden="true">
        <svg ref={svg} className={s.lines}>
          {LINKS.map((_, i) => (
            <line key={i} />
          ))}
        </svg>
        {hero.collage.map((id, i) => {
          const p = LAYOUT[i];
          return (
            <div
              key={id}
              className={s.item}
              data-mobile={p.mx > -99}
              style={
                {
                  "--x": `${p.x}%`,
                  "--y": `${p.y}%`,
                  "--w": `${p.w}vw`,
                  "--mx": `${p.mx}%`,
                  "--my": `${p.my}%`,
                  "--mw": `${p.mw}vw`,
                  "--r": `${p.r}deg`,
                  zIndex: Math.round(p.d * 10),
                } as React.CSSProperties
              }
            >
              <div className={s.drift}>
                <div className={s.card} style={{ filter: `brightness(${0.45 + p.d * 0.4})` }}>
                  <Img slot={id} eager={i < 4} className={s.img} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className={s.center}>
        <h1 className={`${s.name} display`}>
          {"FLO.".split("").map((ch, i) => (
            <span className="mask" key={i}>
              <span>{ch}</span>
            </span>
          ))}
        </h1>
        <div className={s.sub}>
          {hero.sub.map((l) => (
            <span className="mask" key={l}>
              <span className="meta">{l}</span>
            </span>
          ))}
        </div>
      </div>

      <p className={`${s.claim} serif`}>
        <span className="mask">
          <span>{hero.claim}</span>
        </span>
      </p>

      <div className={`${s.cue} meta`}>
        Weiter scrollen <span aria-hidden="true">↓</span>
      </div>
    </section>
  );
}
