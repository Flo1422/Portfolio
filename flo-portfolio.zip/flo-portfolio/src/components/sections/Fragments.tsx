"use client";
import { useRef } from "react";
import { hero } from "@/data/site";
import { gsap, useGSAP, MQ } from "@/lib/gsap";
import s from "./Fragments.module.css";

/** Biografische Fragmente – nur ein Teaser, die ganze Geschichte folgt in „Mein Weg“. */
export function Fragments() {
  const root = useRef<HTMLElement>(null);
  useGSAP(
    () => {
      gsap.matchMedia().add({ motion: MQ.motion, desktop: MQ.desktop }, (ctx) => {
        const { motion, desktop } = ctx.conditions as { motion: boolean; desktop: boolean };
        if (!motion || !desktop) return;
        const track = root.current!.querySelector<HTMLElement>(`.${s.track}`)!;
        root.current!.classList.add(s.driven);
        const dist = () => track.scrollWidth - window.innerWidth * 0.55;
        gsap.fromTo(
          track,
          { x: () => window.innerWidth * 0.35 },
          {
            x: () => -dist(),
            ease: "none",
            scrollTrigger: { trigger: root.current, start: "top bottom", end: "bottom top", scrub: 0.8, invalidateOnRefresh: true },
          },
        );
        gsap.from(`.${s.year}`, {
          yPercent: 60,
          opacity: 0,
          duration: 1.2,
          stagger: 0.07,
          scrollTrigger: { trigger: root.current, start: "top 75%", once: true },
        });
        return () => root.current?.classList.remove(s.driven);
      });
    },
    { scope: root },
  );

  return (
    <section ref={root} className={s.fragments} aria-label="Kurz vorweg: Fragmente aus meinem Leben">
      <div className={`${s.head} wrap`}>
        <span className="meta">Kurz vorweg</span>
        <a className="xref" href="#mein-weg">
          Die ganze Geschichte: Mein Weg
        </a>
      </div>
      <ol className={s.track}>
        {hero.fragments.map((f) => (
          <li key={f.year} className={s.frag}>
            <span className={`${s.year} display`}>{f.year}</span>
            <span className={s.node} aria-hidden="true" />
            <span className={`${s.text} serif`}>{f.text}</span>
          </li>
        ))}
      </ol>
    </section>
  );
}
