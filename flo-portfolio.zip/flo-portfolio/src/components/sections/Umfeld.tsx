"use client";
import { useState } from "react";
import { umfeldOutro } from "@/data/people";
import { ChapterHead } from "@/components/core/ChapterHead";
import { MaskText } from "@/components/core/MaskText";
import { Network } from "@/components/umfeld/Network";
import { Explorer } from "@/components/umfeld/Explorer";
import { Circle } from "@/components/umfeld/Circle";
import { Chain } from "@/components/umfeld/Chain";
import { Linus } from "@/components/umfeld/Linus";
import { FamilyTree } from "@/components/umfeld/FamilyTree";
import s from "@/components/umfeld/Umfeld.module.css";

export function Umfeld() {
  const [asList, setAsList] = useState(false);
  return (
    <section id="mein-umfeld" className={`${s.umfeld} chapter`} aria-labelledby="umfeld-title">
      <div className="wrap">
        <ChapterHead nr="03" label="Mein Umfeld" />
        <div className={s.intro}>
          <MaskText id="umfeld-title" lines={["Alles hängt", "zusammen."]} className={`${s.title} display`} />
          <p className={`${s.lead} serif`}>Im Zentrum: ich. Darum die Bereiche meines Lebens und die Menschen, die sie miteinander verbinden.</p>
        </div>

        <div className={s.modeBar}>
          <button className={s.modeBtn} aria-pressed={asList} onClick={() => setAsList((v) => !v)}>
            {asList ? "Als Karte anzeigen" : "Als Liste anzeigen"}
          </button>
        </div>
        <div className={s.netDesktop} data-hidden={asList}>
          <Network />
        </div>
        <div className={s.netMobile} data-force={asList}>
          <Explorer />
        </div>
      </div>

      <Circle />

      <div className="wrap">
        <Chain />
        <Linus />
        <FamilyTree />
        <div className={s.outro}>
          {umfeldOutro.map((t, i) => (
            <p key={i} className={i === 0 ? `${s.outroLead} serif` : s.outroText}>
              {t}
            </p>
          ))}
        </div>
      </div>
    </section>
  );
}
