"use client";
import { useRef } from "react";
import { outro } from "@/data/site";
import { Img } from "@/components/core/Img";
import { Magnetic } from "@/components/core/Magnetic";
import { useScroll } from "@/components/core/SmoothScroll";
import { gsap, useGSAP, MQ } from "@/lib/gsap";
import s from "./Outro.module.css";

/** Reduzierter Abschluss – keine Reflexionsseite. */
export function Outro() {
  const root = useRef<HTMLElement>(null);
  const { scrollTo } = useScroll();
  useGSAP(
    () => {
      gsap.matchMedia().add(MQ.motion, () => {
        const tl = gsap.timeline({ scrollTrigger: { trigger: root.current, start: "top 60%", once: true } });
        tl.fromTo(`.${s.q} .mask > span`, { yPercent: 140 }, { yPercent: 0, duration: 1.3, stagger: 0.1 })
          .fromTo(`.${s.lines} li`, { opacity: 0, x: -20 }, { opacity: 1, x: 0, stagger: 0.18, duration: 0.9 }, "-=0.6")
          .fromTo(`.${s.closer}`, { opacity: 0 }, { opacity: 1, duration: 1.4 }, "-=0.2");
        gsap.fromTo(`.${s.bg}`, { yPercent: -10, scale: 1.1 }, { yPercent: 10, scale: 1, ease: "none", scrollTrigger: { trigger: root.current, start: "top bottom", end: "bottom bottom", scrub: true } });
      });
    },
    { scope: root },
  );
  return (
    <footer ref={root} className={s.outro} id="outro">
      <div className={s.bg} aria-hidden="true">
        <Img slot="outro" />
      </div>
      <div className={`${s.inner} wrap`}>
        <h2 className={`${s.q} display`}>
          <span className="mask">
            <span>Was kommt</span>
          </span>
          <span className="mask">
            <span>danach?</span>
          </span>
        </h2>
        <ul className={s.lines}>
          {outro.lines.map((l) => (
            <li key={l}>{l}</li>
          ))}
        </ul>
        <p className={`${s.closer} serif`}>{outro.closer}</p>
        <div className={s.foot}>
          <span className="meta">{outro.footer}</span>
          <Magnetic>
            <button className={s.top} onClick={() => scrollTo(document.body)} data-cursor="NACH OBEN">
              Zurück nach oben ↑
            </button>
          </Magnetic>
        </div>
      </div>
    </footer>
  );
}
