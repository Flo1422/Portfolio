"use client";
import { useRef, useState } from "react";
import { about } from "@/data/site";
import { Img } from "@/components/core/Img";
import { MaskText } from "@/components/core/MaskText";
import { ChapterHead } from "@/components/core/ChapterHead";
import { gsap, useGSAP, MQ } from "@/lib/gsap";
import s from "./About.module.css";

export function About() {
  const root = useRef<HTMLElement>(null);
  const [energy, setEnergy] = useState<"hoch" | "niedrig">("hoch");

  useGSAP(
    () => {
      const mm = gsap.matchMedia();
      mm.add({ motion: MQ.motion, desktop: MQ.desktop, fine: MQ.fine }, (ctx) => {
        const { motion, desktop, fine } = ctx.conditions as Record<string, boolean>;
        if (!motion) return;

        // Interessenbegriffe driften durch den Hintergrund
        gsap.utils.toArray<HTMLElement>(`.${s.driftRow}`).forEach((row, i) => {
          gsap.fromTo(
            row,
            { xPercent: i % 2 ? -30 : 0 },
            { xPercent: i % 2 ? 0 : -30, ease: "none", scrollTrigger: { trigger: root.current, start: "top bottom", end: "bottom top", scrub: 1 } },
          );
        });

        // Porträt: Maskenöffnung + leichte Parallax
        gsap.fromTo(`.${s.portrait}`, { clipPath: "inset(18% 12% 18% 12%)" }, {
          clipPath: "inset(0% 0% 0% 0%)",
          duration: 1.6,
          scrollTrigger: { trigger: `.${s.portrait}`, start: "top 85%", once: true },
        });
        gsap.to(`.${s.print}`, { yPercent: -35, rotate: 8, ease: "none", scrollTrigger: { trigger: `.${s.intro}`, start: "top bottom", end: "bottom top", scrub: true } });

        // Fakten: Zeile für Zeile
        gsap.from(`.${s.facts} > div`, { x: -20, opacity: 0, stagger: 0.08, duration: 0.9, scrollTrigger: { trigger: `.${s.facts}`, start: "top 85%", once: true } });

        // Eigenschaften: Wort für Wort
        gsap.from(`.${s.traits} li`, { yPercent: 100, opacity: 0, stagger: 0.035, duration: 0.8, scrollTrigger: { trigger: `.${s.traits}`, start: "top 88%", once: true } });

        // Werte: Breite wächst mit dem Scroll
        gsap.utils.toArray<HTMLElement>(`.${s.valueWord}`).forEach((w) => {
          gsap.fromTo(w, { fontVariationSettings: "'wdth' 62" }, {
            fontVariationSettings: "'wdth' 112",
            ease: "none",
            scrollTrigger: { trigger: w, start: "top 95%", end: "top 35%", scrub: true },
          });
        });

        // Nicht perfekt: Karten fächern sich auf
        if (desktop) {
          const cards = gsap.utils.toArray<HTMLElement>(`.${s.card}`);
          gsap.fromTo(
            cards,
            { x: (i) => (1 - i) * 360, y: (i) => i * 12, rotate: (i) => (i - 1) * 6 },
            {
              x: 0,
              y: 0,
              rotate: (i) => [-2.5, 1, 3][i],
              ease: "power2.out",
              scrollTrigger: { trigger: `.${s.cards}`, start: "top 90%", end: "top 30%", scrub: 0.8 },
            },
          );
        }

        // Karten & Porträt kippen zur Maus
        if (fine) {
          const tilt = (el: HTMLElement, amt: number) => {
            const rx = gsap.quickTo(el, "rotationX", { duration: 0.6, ease: "power3" });
            const ry = gsap.quickTo(el, "rotationY", { duration: 0.6, ease: "power3" });
            const move = (e: PointerEvent) => {
              const r = el.getBoundingClientRect();
              ry(((e.clientX - r.left) / r.width - 0.5) * amt);
              rx(-((e.clientY - r.top) / r.height - 0.5) * amt);
            };
            const leave = () => {
              rx(0);
              ry(0);
            };
            el.addEventListener("pointermove", move);
            el.addEventListener("pointerleave", leave);
            return () => {
              el.removeEventListener("pointermove", move);
              el.removeEventListener("pointerleave", leave);
            };
          };
          const offs = [
            ...gsap.utils.toArray<HTMLElement>(`.${s.cardInner}`).map((c) => tilt(c, 14)),
            ...gsap.utils.toArray<HTMLElement>(`.${s.portraitTilt}`).map((c) => tilt(c, 8)),
          ];
          return () => offs.forEach((o) => o());
        }
      });
    },
    { scope: root },
  );

  return (
    <section ref={root} id="ueber-mich" className={`${s.about} chapter`} aria-labelledby="about-title">
      {/* Hintergrund: driftende Interessen */}
      <div className={s.drift} aria-hidden="true">
        {[0, 1].map((r) => (
          <div key={r} className={`${s.driftRow} display`}>
            {[...about.interests, ...about.interests].map((w, i) => (
              <span key={i}>{w}</span>
            ))}
          </div>
        ))}
      </div>

      <div className="wrap">
        <ChapterHead nr="01" label="Über mich" />

        {/* ── Intro ── */}
        <div className={s.intro}>
          <div className={s.visual}>
            <div className={s.portraitTilt} data-cursor="ANSEHEN">
              <Img slot="about-portrait" className={s.portrait} />
            </div>
            <div className={s.print}>
              <Img slot="about-portrait-2" />
            </div>
          </div>
          <div className={s.introText}>
            <MaskText id="about-title" lines={["Hey,", "ich bin", "Flo."]} className={`${s.title} display`} />
            <dl className={s.facts}>
              {about.facts.map((f) => (
                <div key={f.label}>
                  <dt className="meta">{f.label}</dt>
                  <dd>{f.value}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>

        {/* ── Das bin ich ── */}
        <div className={s.self}>
          <h3 className={`${s.kicker} meta`}>Das bin ich</h3>
          <p className={`${s.selfLead} serif`}>{about.text[0]}</p>
          <div className={s.selfCols}>
            {about.text.slice(1).map((t, i) => (
              <p key={i}>{t}</p>
            ))}
          </div>
          <ul className={s.traits} aria-label="Eigenschaften">
            {about.traits.map((t) => (
              <li key={t}>{t}</li>
            ))}
          </ul>
        </div>

        {/* ── Was mich ausmacht & Werte ── */}
        <div className={s.values}>
          <div className={s.core}>
            <h3 className={`${s.kicker} meta`}>Was mich ausmacht</h3>
            <ol>
              {about.core.map((c, i) => (
                <li key={c}>
                  <span className="meta">0{i + 1}</span>
                  <span className={s.coreWord}>{c}</span>
                </li>
              ))}
            </ol>
          </div>
          <div className={s.valueList}>
            <h3 className={`${s.kicker} meta`}>Meine Werte</h3>
            {about.values.map((v) => (
              <div key={v.word} className={s.value}>
                <span className={`${s.valueWord} display`}>{v.word}</span>
                <span className={`${s.valueNote} serif`}>{v.note}</span>
              </div>
            ))}
          </div>
        </div>

        {/* ── Nicht perfekt ── */}
        <div className={s.imperfect}>
          <MaskText lines={["Nicht", "perfekt."]} className={`${s.imperfectTitle} display`} />
          <div className={s.cards}>
            {about.imperfect.map((c, i) => (
              <article key={c.title} className={s.card}>
                <div className={s.cardInner}>
                  <span className="meta">0{i + 1}</span>
                  <h4 className="display">{c.title}</h4>
                  <p>{c.text}</p>

                  {i === 0 && (
                    <div className={s.meter}>
                      <div className={s.meterBar} style={{ transform: `scaleX(${energy === "hoch" ? 1 : 0.2})` }} />
                      <div className={s.meterBtns} role="group" aria-label="Begeisterung umschalten">
                        <button aria-pressed={energy === "hoch"} onClick={() => setEnergy("hoch")}>
                          Begeistert · 100 %
                        </button>
                        <button aria-pressed={energy === "niedrig"} onClick={() => setEnergy("niedrig")}>
                          Nicht · 20 %
                        </button>
                      </div>
                    </div>
                  )}
                  {i === 1 && (
                    <svg className={s.pathSvg} viewBox="0 0 240 60" aria-hidden="true">
                      <path className={s.pathLong} d="M8 30 C 40 -10, 60 70, 95 30 S 150 -5, 170 32 S 215 60, 232 30" />
                      <path className={s.pathShort} d="M8 30 L232 30" />
                      <circle cx="8" cy="30" r="4" />
                      <circle cx="232" cy="30" r="4" />
                    </svg>
                  )}
                  {i === 2 && (
                    <span className={`${s.quoteMark} serif`} aria-hidden="true">
                      „
                    </span>
                  )}
                </div>
              </article>
            ))}
          </div>
        </div>

        {/* ── Stil ── */}
        <div className={s.style}>
          <Img slot="about-style" className={s.styleImg} />
          <div>
            <h3 className={`${s.kicker} meta`}>Stil</h3>
            <p className={`${s.styleText} serif`}>{about.style}</p>
          </div>
        </div>
      </div>
    </section>
  );
}
