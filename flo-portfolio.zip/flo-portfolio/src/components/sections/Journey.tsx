"use client";
import { useRef, useState } from "react";
import { timeline, nowItems, future, type TimelineEntry } from "@/data/timeline";
import { areas } from "@/data/people";
import { Img } from "@/components/core/Img";
import { MaskText } from "@/components/core/MaskText";
import { ChapterHead } from "@/components/core/ChapterHead";
import { gsap, useGSAP, ScrollTrigger, MQ } from "@/lib/gsap";
import s from "./Journey.module.css";

const areaById = Object.fromEntries(areas.map((a) => [a.id, a]));
const startYear = (e: TimelineEntry) => e.when.match(/\d{4}/)?.[0] ?? "";

function Entry({ e }: { e: TimelineEntry }) {
  return (
    <li className={s.entry} data-year={startYear(e)} data-kind={e.kind ?? "normal"}>
      <span className={s.node} aria-hidden="true" />
      <div className={s.entryGrid}>
        <div className={s.textCol}>
          <span className={`${s.when} meta`}>{e.when}</span>
          <h3 className={s.title}>
            <span>{e.title}</span>
          </h3>
          <div className={s.body}>
            {e.meta && <p className={s.meta}>{e.meta}</p>}
            {e.text && <p className={s.text}>{e.text}</p>}
            {e.kind === "now" && (
              <ul className={s.nowList}>
                {nowItems.map((n) => (
                  <li key={n}>{n}</li>
                ))}
              </ul>
            )}
            {e.areas.length > 0 && (
              <ul className={s.chips} aria-label="Bereiche">
                {e.areas.map((a) => (
                  <li key={a} style={{ "--c": areaById[a].color } as React.CSSProperties}>
                    {areaById[a].label}
                  </li>
                ))}
              </ul>
            )}
            {e.link && (
              <a className="xref" href={`#${e.link.to}`}>
                {e.link.label}
              </a>
            )}
          </div>
        </div>
        {e.media && (
          <div className={s.photoWrap}>
            <Img slot={e.media} className={s.photo} />
          </div>
        )}
      </div>
    </li>
  );
}

export function Journey() {
  const root = useRef<HTMLElement>(null);
  const [year, setYear] = useState("2004");

  // Aufteilen: vor dem Wendepunkt · Wendepunkt · danach
  const turnIdx = timeline.findIndex((e) => e.kind === "turning");
  const before = timeline.slice(0, turnIdx);
  const turning = timeline[turnIdx];
  const after = timeline.slice(turnIdx + 1);

  useGSAP(
    () => {
      // Jahreszahl im Hintergrund folgt dem Fortschritt (auch ohne Bewegung sinnvoll)
      gsap.utils.toArray<HTMLElement>(`[data-year]`).forEach((el) => {
        ScrollTrigger.create({
          trigger: el,
          start: "top 60%",
          end: "bottom 60%",
          onToggle: (self) => self.isActive && setYear(el.dataset.year!),
        });
      });

      gsap.matchMedia().add(MQ.motion, () => {
        // Linie zeichnet sich
        gsap.utils.toArray<HTMLElement>(`.${s.lineFill}`).forEach((l) => {
          gsap.fromTo(l, { scaleY: 0 }, {
            scaleY: 1,
            ease: "none",
            scrollTrigger: { trigger: l.parentElement, start: "top 60%", end: "bottom 60%", scrub: true },
          });
        });
        // Einträge
        gsap.utils.toArray<HTMLElement>(`.${s.entry}`).forEach((e) => {
          const tl = gsap.timeline({ scrollTrigger: { trigger: e, start: "top 80%", once: true } });
          tl.from(e.querySelector(`.${s.node}`), { scale: 0, duration: 0.6, ease: "back.out(3)" })
            .from(e.querySelector(`.${s.when}`), { x: -24, opacity: 0, duration: 0.8 }, 0.05)
            .from(e.querySelector(`.${s.title} > span`), { yPercent: 105, duration: 1 }, 0.1)
            .from(e.querySelectorAll(`.${s.body} > *`), { y: 16, opacity: 0, stagger: 0.06, duration: 0.8 }, 0.25);
          const img = e.querySelector(`.${s.photo}`);
          if (img) {
            tl.fromTo(img, { clipPath: "inset(0 0 100% 0)" }, { clipPath: "inset(0 0 0% 0)", duration: 1.3, ease: "expo.inOut" }, 0.1);
            gsap.to(img, { yPercent: -12, ease: "none", scrollTrigger: { trigger: e, start: "top bottom", end: "bottom top", scrub: true } });
          }
        });
        // Wendepunkt: der Hintergrund verdichtet sich, der Text kommt ruhig
        gsap.from(`.${s.turnWord}`, {
          letterSpacing: "0.4em",
          opacity: 0,
          duration: 1.8,
          ease: "power3.out",
          scrollTrigger: { trigger: `.${s.turning}`, start: "top 70%", once: true },
        });
        // Heute: Knoten verbinden sich
        gsap.from(`.${s.nowList} li`, {
          scale: 0.6,
          opacity: 0,
          stagger: 0.06,
          duration: 0.7,
          ease: "back.out(2)",
          scrollTrigger: { trigger: `.${s.nowList}`, start: "top 85%", once: true },
        });
      });
    },
    { scope: root },
  );

  return (
    <section ref={root} id="mein-weg" className={`${s.journey} chapter`} aria-labelledby="weg-title">
      <div className="wrap">
        <ChapterHead nr="02" label="Mein Weg" />
        <MaskText id="weg-title" lines={["Von 2004", "bis heute."]} className={`${s.headline} display`} />
      </div>

      <div className={`${s.body0} wrap`}>
        <div className={s.stickyYear} aria-hidden="true">
          <span key={year} className="display">
            {year}
          </span>
        </div>

        <div className={s.col}>
          <div className={s.list}>
            <span className={s.line} aria-hidden="true">
              <span className={s.lineFill} />
            </span>
            <ol>
              {before.map((e) => (
                <Entry key={e.id} e={e} />
              ))}
            </ol>
          </div>
        </div>
      </div>

      {/* Wendepunkt – bewusst anders, sachlich */}
      <div className={s.turning} data-year="2021">
        <div className={`${s.turningInner} wrap`}>
          <span className="meta">{turning.when}</span>
          <h3 className={`${s.turnWord} display`}>{turning.title}</h3>
          <p className={s.turnText}>{turning.text}</p>
        </div>
      </div>

      <div className={`${s.body0} wrap`}>
        <div className={s.stickyYear} aria-hidden="true">
          <span key={year} className="display">
            {year}
          </span>
        </div>
        <div className={s.col}>
          <div className={s.list}>
            <span className={s.line} aria-hidden="true">
              <span className={s.lineFill} />
            </span>
            <ol>
              {after.map((e) => (
                <Entry key={e.id} e={e} />
              ))}
            </ol>
          </div>
          <p className={`${s.future} serif`}>{future}</p>
        </div>
      </div>
    </section>
  );
}
