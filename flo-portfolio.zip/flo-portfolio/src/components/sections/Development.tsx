"use client";
import { useRef } from "react";
import { development as d } from "@/data/development";
import { ChapterHead } from "@/components/core/ChapterHead";
import { MaskText } from "@/components/core/MaskText";
import { Img } from "@/components/core/Img";
import { gsap, useGSAP, MQ } from "@/lib/gsap";
import s from "./Development.module.css";

export function Development() {
  const root = useRef<HTMLElement>(null);

  useGSAP(
    () => {
      gsap.matchMedia().add({ motion: MQ.motion, desktop: MQ.desktop }, (ctx) => {
        const { motion } = ctx.conditions as Record<string, boolean>;
        if (!motion) return;
        // Weg wächst durch die Stationen
        gsap.fromTo(`.${s.pathFill}`, { scaleY: 0 }, {
          scaleY: 1,
          ease: "none",
          scrollTrigger: { trigger: `.${s.stations}`, start: "top 55%", end: "bottom 55%", scrub: true },
        });
        gsap.utils.toArray<HTMLElement>(`.${s.station}`).forEach((st) => {
          gsap.fromTo(st.querySelector(`.${s.sNode}`), { scale: 0.3, backgroundColor: "var(--bg-0)" }, {
            scale: 1,
            backgroundColor: "var(--fg)",
            scrollTrigger: { trigger: st, start: "top 55%", toggleActions: "play none none reverse" },
            duration: 0.5,
          });
        });
        // Kita-Kind → Schülerpraktikant → Erzieherausbildung
        gsap.fromTo(`.${s.motif} li`, { opacity: 0.2 }, {
          opacity: 1,
          stagger: 0.5,
          ease: "none",
          scrollTrigger: { trigger: `.${s.motif}`, start: "top 85%", end: "top 45%", scrub: true },
        });
        // Integration: Fortschritt
        gsap.fromTo(`.${s.intFill}`, { scaleX: 0 }, {
          scaleX: 1,
          ease: "none",
          scrollTrigger: { trigger: `.${s.intSteps}`, start: "top 85%", end: "top 35%", scrub: true },
        });
        gsap.fromTo(`.${s.intSteps} li`, { opacity: 0.25 }, {
          opacity: 1,
          stagger: 0.33,
          ease: "none",
          scrollTrigger: { trigger: `.${s.intSteps}`, start: "top 85%", end: "top 35%", scrub: true },
        });
        // Verzweigung
        const tl = gsap.timeline({ scrollTrigger: { trigger: `.${s.branches}`, start: "top 75%", end: "center 55%", scrub: 0.6 } });
        tl.fromTo(`.${s.trunk}`, { strokeDashoffset: 1 }, { strokeDashoffset: 0, duration: 1 })
          .fromTo(`.${s.branch}`, { strokeDashoffset: 1 }, { strokeDashoffset: 0, duration: 1.4, stagger: 0.1 })
          .fromTo(`.${s.bCard}`, { opacity: 0, y: 30 }, { opacity: 1, y: 0, stagger: 0.15, duration: 0.8 }, "-=0.6")
          .fromTo(`.${s.cross}`, { strokeDashoffset: 1 }, { strokeDashoffset: 0, duration: 1 }, "-=0.4")
          .fromTo(`.${s.crossLabel}`, { opacity: 0 }, { opacity: 1, duration: 0.4 });
      });
    },
    { scope: root },
  );

  return (
    <section ref={root} id="meine-entwicklung" className={`${s.dev} chapter`} aria-labelledby="entw-title">
      <div className="wrap">
        <ChapterHead nr="05" label="Meine Entwicklung" />
        <div className={s.head}>
          <MaskText id="entw-title" lines={["Meinen Platz", "finden."]} className={`${s.title} display`} />
          <p className={`${s.intro} serif`}>{d.intro}</p>
        </div>

        {/* ── Stationen ── */}
        <div className={s.stations}>
          <div className={s.path} aria-hidden="true">
            <span className={s.pathFill} />
          </div>
          {d.stations.map((st, i) => (
            <article key={st.id} className={s.station}>
              <span className={s.sNode} aria-hidden="true" />
              <div className={s.sHead}>
                <span className="meta">{st.when}</span>
                <h3 className="display">{st.title}</h3>
                <p className={s.place}>{st.place}</p>
              </div>
              <div className={s.sBody}>
                {st.text.map((t, k) => (
                  <p key={k}>{t}</p>
                ))}
                {"motif" in st && st.motif && (
                  <ol className={s.motif} aria-label="Vom Kita-Kind zur Ausbildung">
                    {st.motif.map((m) => (
                      <li key={m} className="display">
                        {m}
                      </li>
                    ))}
                  </ol>
                )}
                {"result" in st && st.result && (
                  <div className={s.result}>
                    <span className="meta">Danach wusste ich</span>
                    {st.result.map((r) => (
                      <p key={r} className="serif">
                        {r}
                      </p>
                    ))}
                  </div>
                )}
                {i === 0 && <Img slot="entw-kita" className={s.sImg} />}
              </div>
            </article>
          ))}
        </div>

        {/* ── Umgang ── */}
        <div className={s.approach} id="entw-umgang">
          <span className="meta signal">{d.approach.title}</span>
          <p className={`${s.statement} serif`}>{d.approach.statement}</p>
          <div className={s.approachText}>
            {d.approach.text.map((t, i) => (
              <p key={i}>{t}</p>
            ))}
          </div>
        </div>

        {/* ── Integration ── */}
        <div className={s.integration} id="entw-integration">
          <div>
            <span className="meta signal">{d.integration.title}</span>
            <h3 className={`${s.h3} display`}>Aus Unsicherheit wird Interesse.</h3>
            {d.integration.text.map((t, i) => (
              <p key={i}>{t}</p>
            ))}
          </div>
          <div className={s.intSteps}>
            <span className={s.intTrack} aria-hidden="true">
              <span className={s.intFill} />
            </span>
            <ol>
              {d.integration.steps.map((x, i) => (
                <li key={x}>
                  <span className="meta">0{i + 1}</span>
                  <span className="display">{x}</span>
                </li>
              ))}
            </ol>
          </div>
        </div>

        {/* ── Arbeitsfelder: der Weg verzweigt sich ── */}
        <div className={s.fields} id="entw-felder">
          <span className="meta signal">Altersgruppen & Arbeitsfelder</span>
          <div className={s.branches}>
            <svg viewBox="0 0 1000 300" className={s.branchSvg} aria-hidden="true" preserveAspectRatio="none">
              <path className={s.trunk} pathLength={1} d="M500 0 L500 110" />
              <path className={s.branch} pathLength={1} d="M500 110 C 500 200, 167 190, 167 300" />
              <path className={s.branch} pathLength={1} d="M500 110 L500 300" />
              <path className={s.branch} pathLength={1} d="M500 110 C 500 200, 833 190, 833 300" />
              <path className={s.cross} pathLength={1} d="M30 230 L970 230" />
            </svg>
            <div className={`${s.trunkLabel} display`}>Erzieherausbildung</div>
            <span className={`${s.crossLabel} meta`}>Integration: quer dazu, in jedem Feld</span>
            <div className={s.bCards}>
              {d.branches.map((b) => (
                <div key={b.id} className={s.bCard}>
                  <h4 className="display">{b.label}</h4>
                  <p>{b.text}</p>
                </div>
              ))}
            </div>
          </div>
          <p className={`${s.open} meta`}>{d.openQuestion}</p>
          <blockquote className={`${s.core} serif`}>{d.core}</blockquote>
        </div>
      </div>
    </section>
  );
}
