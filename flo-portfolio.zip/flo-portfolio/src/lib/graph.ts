import { forceSimulation, forceLink, forceManyBody, forceCollide, forceX, forceY, type SimulationNodeDatum } from "d3-force";
import { areas, people, relations, type AreaId } from "@/data/people";

export const W = 1200;
export const H = 860;
const CX = W / 2;
const CY = H / 2;

/** Reihenfolge der Bereiche im Kreis – Nachbarn sind thematisch verwandt */
const RING: AreaId[] = ["familie", "kindheit", "ausbildung", "arbeit", "motorrad", "musik", "graffiti", "freunde"];

export type GNode = SimulationNodeDatum & {
  id: string;
  kind: "me" | "area" | "person";
  label: string;
  r: number;
  color?: string;
  areas?: AreaId[];
  key?: boolean;
};
export type GLink = { id: string; source: string; target: string; kind: "me" | "member" | "relation"; label?: string };

let cache: { nodes: GNode[]; links: GLink[] } | null = null;

/** Deterministisches Layout (gleiches Ergebnis auf Server und Client) */
export function buildGraph() {
  if (cache) return cache;
  const areaPos: Record<string, { x: number; y: number }> = {};
  RING.forEach((id, i) => {
    const a = (i / RING.length) * Math.PI * 2 - Math.PI / 2 - Math.PI / 8;
    areaPos[id] = { x: CX + Math.cos(a) * 345, y: CY + Math.sin(a) * 250, a } as { x: number; y: number };
  });

  const nodes: GNode[] = [
    { id: "flo", kind: "me", label: "Flo", r: 16, x: CX, y: CY, fx: CX, fy: CY },
    ...areas.map<GNode>((a) => ({
      id: a.id,
      kind: "area",
      label: a.label,
      r: 8,
      color: a.color,
      x: areaPos[a.id].x,
      y: areaPos[a.id].y,
      fx: areaPos[a.id].x,
      fy: areaPos[a.id].y,
    })),
  ];

  // Menschen mit nur einem Bereich: in Bögen um „ihren“ Bereich (nach außen gerichtet)
  const target: Record<string, { x: number; y: number }> = {};
  const singles: Record<string, string[]> = {};
  people.forEach((p) => {
    if (p.areas.length === 1) (singles[p.areas[0]] ??= []).push(p.id);
  });
  Object.entries(singles).forEach(([area, ids]) => {
    const ap = areaPos[area];
    const base = Math.atan2(ap.y - CY, ap.x - CX);
    const perRing = 8;
    ids.forEach((id, i) => {
      const ring = Math.floor(i / perRing);
      const inRing = Math.min(perRing, ids.length - ring * perRing);
      const k = i % perRing;
      const spread = Math.min(Math.PI * 0.95, 0.32 * inRing);
      const ang = base + (inRing === 1 ? 0 : -spread / 2 + (spread * k) / (inRing - 1)) + ring * 0.12;
      const r = 92 + ring * 50;
      target[id] = { x: ap.x + Math.cos(ang) * r, y: ap.y + Math.sin(ang) * r * 0.9 };
    });
  });
  people.forEach((p, idx) => {
    if (!target[p.id]) {
      const pts = p.areas.map((a) => areaPos[a]);
      let x = pts.reduce((s, q) => s + q.x, 0) / pts.length;
      let y = pts.reduce((s, q) => s + q.y, 0) / pts.length;
      const dx = x - CX, dy = y - CY;
      const len = Math.hypot(dx, dy) || 1;
      const want = Math.max(len * 1.15, 140);
      x = CX + (dx / len) * want;
      y = CY + (dy / len) * want;
      target[p.id] = { x, y };
    }
    const t = target[p.id];
    nodes.push({
      id: p.id,
      kind: "person",
      label: p.name,
      r: p.key ? 5.5 : 3.5,
      areas: p.areas,
      key: p.key,
      x: t.x + (((idx * 97) % 11) - 5),
      y: t.y + (((idx * 53) % 11) - 5),
    });
  });

  const links: GLink[] = [
    ...areas.map<GLink>((a) => ({ id: `l-flo-${a.id}`, source: "flo", target: a.id, kind: "me" })),
    ...people.flatMap((p) => p.areas.map<GLink>((a) => ({ id: `l-${p.id}-${a}`, source: p.id, target: a, kind: "member" }))),
    ...relations.map<GLink>((r) => ({ id: `r-${r.from}-${r.to}`, source: r.from, target: r.to, kind: "relation", label: r.label })),
  ];

  const simLinks = links.filter((l) => l.kind === "member").map((l) => ({ source: l.source, target: l.target }));
  const sim = forceSimulation(nodes)
    .randomSource(() => 0.5)
    .force("link", forceLink<GNode, { source: string; target: string }>(simLinks).id((d) => d.id).distance(70).strength(0.05))
    .force("charge", forceManyBody().strength(-12))
    .force("collide", forceCollide<GNode>().radius((d) => (d.kind === "person" ? 19 : d.kind === "area" ? 36 : 54)).strength(0.8))
    .force("x", forceX<GNode>((d) => (d.kind === "person" ? target[d.id].x : d.x!)).strength(0.5))
    .force("y", forceY<GNode>((d) => (d.kind === "person" ? target[d.id].y : d.y!)).strength(0.5))
    .stop();
  for (let i = 0; i < 420; i++) sim.tick();
  // innerhalb der Fläche halten
  nodes.forEach((n) => {
    n.x = Math.max(40, Math.min(W - 40, n.x!));
    n.y = Math.max(30, Math.min(H - 30, n.y!));
  });
  cache = { nodes, links };
  return cache;
}

/** Welche Knoten/Linien gehören zu einem Fokus? */
export function neighborhood(ids: string[], links: GLink[]) {
  const set = new Set(ids);
  const nodeSet = new Set(ids);
  const linkSet = new Set<string>();
  links.forEach((l) => {
    if (set.has(l.source) || set.has(l.target)) {
      // bei Personen/Bereichen: direkte Nachbarn einblenden
      linkSet.add(l.id);
      nodeSet.add(l.source);
      nodeSet.add(l.target);
    }
  });
  return { nodes: nodeSet, links: linkSet };
}

/** Für Geschichten: nur Verbindungen innerhalb der Auswahl */
export function subset(ids: string[], links: GLink[]) {
  const set = new Set([...ids, "flo"]);
  const linkSet = new Set<string>();
  links.forEach((l) => set.has(l.source) && set.has(l.target) && linkSet.add(l.id));
  return { nodes: set, links: linkSet };
}
